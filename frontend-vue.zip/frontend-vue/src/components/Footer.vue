<template>
    <footer class="bg-gray-800 text-white py-6">
      <div class="container mx-auto text-center">
        <p>&copy; 2024 네이버 인공지능 웹개발 프로젝트 3조 '나의 책꽂이'. All rights reserved.</p>
        <ul class="flex justify-center space-x-4 mt-4">
          <li><a href="#privacy" class="hover:text-yellow-300">Privacy Policy</a></li>
          <li><a href="#terms" class="hover:text-yellow-300">Terms of Service</a></li>
          <li><a href="#contact" class="hover:text-yellow-300">Contact Us</a></li>
        </ul>
      </div>
    </footer>
  </template>
  
  <script>
  export default {
    name: 'Footer'
  }
  </script>
  
  <style scoped>
  /* 푸터 스타일 */
  </style>
  