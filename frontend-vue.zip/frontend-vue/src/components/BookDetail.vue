
<template>
  얜 뭐임 있으나 마나..........

  
  <div class="book-detail flex">
    <img :src="book.image || defaultimage" :alt="book.title" class="w-48 h-64 object-cover mr-6">
    <div>
      <h1 class="text-2xl font-semibold mb-2">{{ book.title }}</h1>
      <p class="text-lg">{{ book.author }}</p>
      <p class="text-md text-gray-600">{{ book.publish }} </p>
      <p class="mt-4">{{ book.description }}</p>
    </div>
  </div>
</template>

<script>
import { ref } from 'vue'
import { useRouter } from 'vue-router';
import { fetchWithAuth } from '../util/fetchWithAuth'
import defaultImage from '../data/images/defaultimage.jpg'; // 기본 이미지 경로 가져오기


export default {
  name: 'BookDetail',
  props: {
    book: {
      type: Object,
      required: true
    }
  }
};
</script>