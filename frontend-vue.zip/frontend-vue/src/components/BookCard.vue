<template>
  <div class="book-card bg-white shadow rounded-lg p-4 mb-2 cursor-pointer" @click="goToDetail(book.no)">
    <img :src="book.image || defaultimage" :alt="book.title" class="cover-image" />
    <h3 class="book-title">{{ book.title }}</h3>
    <p class="book-author">{{ book.author }}</p>
    <p class="book-publisher">{{ book.publish }}</p>
    <!-- <p class="isbn">{{ book.isbn }}</p> -->
     
    
            <!-- 소장 도서관 결과 출력 -->
            <div v-if="book.libraryData && book.libraryData.length > 0" class="mt-4">
              <h4 class="font-bold text-md">소장 도서관 목록:</h4>
              <ul class="max-h-40 overflow-y-auto">
                <li v-for="item in book.libraryData" :key="item.lib.libCode" class="text-sm text-gray-600">
                  {{ item.lib.libName }}
                </li>
              </ul>
            </div>
            <div v-else-if="book.libraryData && book.libraryData.length === 0" class="mt-4 text-sm text-gray-600">
              소장 도서관이 없습니다.
            </div>
            <div v-else-if="book.isSearching" class="mt-4 text-sm text-gray-600">
              도서관 정보를 조회 중입니다...
            </div>
    <!-- Library Info Button -->
    <button class="library-button" @click.stop="searchLib(book)">소장 도서관 조회</button>
  </div>



</template>

<script>
import { ref } from 'vue'
import { useRouter } from 'vue-router';
import { fetchWithAuth } from '../util/fetchWithAuth'
import defaultImage from '../data/images/defaultimage.jpg'; // 기본 이미지 경로 가져오기


// 도서관 조회 관련
const libraryData = ref([]); // 배열로 초기화

const searchLib = async (book) => {
  if (book.libraryData) return; // 이미 검색된 경우 재검색 방지
  
  book.isSearching = true;
  try {
    const response = await fetchWithAuth(`/api/search/book?isbn=${book.isbn}&region=29`
    , {
      method: 'GET'
    })

    const lib = await response.json();

    if (response.ok) {
      book.libraryData = lib.response.libs;
    } else {
      console.error('API 응답 구조가 예상과 다릅니다:', response);
      error.value = '소장 도서관 정보를 불러오는데 실패했습니다.';
      book.libraryData = [];
    }
  } catch (error) {
    console.error('소장 도서관을 조회하는 중 오류가 발생했습니다.', error);
    error.value = '소장 도서관 조회 중 오류가 발생했습니다.';
    book.libraryData = [];
  } finally {
    book.isSearching = false;
  }
};




export default {
  name: 'BookCard',
  props: {
    book: {
      type: Object,
      required: true
    }
  },
  setup(props) {
    const router = useRouter();

    const goToDetail = (no) => {
      router.push({ name: 'BookDetail', params: { id: no } });
    };

    const goToLibraryInfo = () => {
      // Add functionality to navigate to the library information page.
      alert(`조회할 도서관 정보: ${props.book.libraryInfo}`);
    };

    return { goToDetail, searchLib, defaultImage };
  }
}
</script>

<style scoped>
.book-card {
  width: 200px; /* Fixed width for all cards */
  height: 400px; /* Increased height for button */
  transition: transform 0.2s;
  overflow: hidden; /* Prevent overflow of content */
  display: flex;
  flex-direction: column;
  justify-content: space-between; /* Distribute space evenly */
}

.cover-image {
  width: auto;
  height: 100%; /* Fixed height for images */
  max-height : 250px;
  object-fit: contain; /* Ensure the image covers the area */
}

.book-title,
.book-author,
.book-publisher {
  margin: 0; /* Remove default margin */
  text-overflow: ellipsis; /* Truncate text with ellipsis */
  overflow: hidden; /* Hide overflow */
  white-space: nowrap; /* Prevent text from wrapping */
}

.book-title {
  font-size: 1rem; /* Adjust font size for title */
  font-weight: bold;
}

.book-author,
.book-publisher {
  font-size: 0.875rem; /* Adjust font size for author and publisher */
  color: #4a5568; /* Slightly darker gray */
}

/* Library button style */
.library-button {
  margin-top: 10px;
  padding: 5px 10px;
  background-color: #4A5568; /* Dark gray background */
  color: white; /* White text */
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.library-button:hover {
  background-color: #2D3748; /* Darker gray on hover */
}

/* Hover effect */
.book-card:hover {
  transform: scale(1.05);
}
</style>
