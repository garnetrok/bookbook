<template>
    <div class="review-form-container">
      <!-- Review Submission Form -->
      <form @submit.prevent="submitReview" class="mb-8 flex items-center space-x-4">
        <div class="flex items-center">
          <!-- Star Rating Selection -->
          <div class="flex space-x-1">
            <svg 
              v-for="star in 5" 
              :key="'star-' + star" 
              @click="setRating(star)" 
              class="w-6 h-6 cursor-pointer" 
              :class="{'text-yellow-400': star <= newReview.rating, 'text-gray-400': star > newReview.rating}" 
              fill="currentColor" 
              viewBox="0 0 20 20">
              <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
            </svg>
          </div>
        </div>
        <input 
          v-model="newReview.reviewer" 
          type="text" 
          class="flex-1 p-2 border rounded" 
          placeholder="이름" 
          required 
          maxlength="20" /> <!-- 이름 최대 20자 -->
        <input 
          v-model="newReview.content" 
          type="text" 
          class="flex-1 p-2 border rounded" 
          placeholder="리뷰 내용" 
          required 
          maxlength="140" /> <!-- 리뷰 최대 140자 -->
        <button type="submit" class="bg-blue-400 text-white px-4 py-2 rounded">리뷰 제출</button>
      </form>
  
      <!-- Existing Reviews Display -->
      <div class="review-container">
        <div v-for="(review, index) in bookReviews" :key="index" class="review-item rounded-lg shadow-md p-4 mb-4">
          <div class="flex items-center justify-between mb-2">
            <div class="flex items-center space-x-2">
              <div class="flex">
                <svg v-for="star in review.rating" :key="'filled-' + star" class="w-5 h-5 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                </svg>
              </div>
              <span>{{ review.reviewer }}</span>
              <span class="text-gray-600">|</span>
              <span class="text-gray-600">{{ formatDate(review.date) }}</span>
            </div>
            <div class="like-button-container ml-4" @click="addLike(index)">
              <div class="flex items-center space-x-1 border rounded-full px-2 py-1 cursor-pointer hover:bg-gray-100 transition duration-200">
                <svg class="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905 0 .714-.211 1.412-.608 2.006L7 11v9m7-10h-2M7 20H5a2 2 0 01-2-2v-6a2 2 0 012-2h2.5"></path>
                </svg>
                <span>{{ review.likes }}</span>
              </div>
            </div>
          </div>
          <p class="text-gray-700">{{ review.content }}</p>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  import { ref, onMounted } from 'vue';
  import books from '../data/books';
  
  export default {
    props: {
      bookId: {
        type: Number,
        required: true
      }
    },
    setup(props) {
      const newReview = ref({ rating: 0, reviewer: '', content: '' });
      const bookReviews = ref([]);
      const hoverRating = ref(0);
  
      const setRating = (rating) => {
        newReview.value.rating = rating;
      };
  
      const submitReview = () => {
        const reviewToSubmit = { ...newReview.value, date: new Date().toISOString(), likes: 0 };
        bookReviews.value.unshift(reviewToSubmit);
        newReview.value = { rating: 0, reviewer: '', content: '' };
      };
  
      const formatDate = (dateString) => {
        return new Date(dateString).toLocaleString('ko-KR', { 
          year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit',
          hour12: false 
        }).replace(/\./g, '-').replace(',', '');
      };
  
      const addLike = (index) => {
        bookReviews.value[index].likes += 1;
      };
  
      onMounted(() => {
        const book = books.find(b => b.id === props.bookId);
        if (book && book.reviews) {
          bookReviews.value = book.reviews;
        }
      });
  
      return {
        newReview,
        bookReviews,
        hoverRating,
        setRating,
        submitReview,
        formatDate,
        addLike
      };
    }
  };
  </script>
  
  <style scoped>
  .review-form-container {
    font-family: Arial, sans-serif;
    width: 80%; /* 화면 전체의 80%만 사용 */
    margin-left: 0; /* 좌측에서 시작 */
    margin-right: auto; /* 중앙 정렬을 막기 위해 오른쪽 여백을 자동으로 설정 */
  }
  .review-item {
    transition: box-shadow 0.3s ease;
  }
  .review-item:hover {
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  }
  .like-button-container {
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 50px;
    padding: 4px 10px;
    cursor: pointer;
    transition: background-color 0.2s ease;
  }
  .like-button-container:hover {
    background-color: rgba(0, 0, 0, 0.05);
  }
  </style>
  