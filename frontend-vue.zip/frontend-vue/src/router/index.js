import { createRouter, createWebHistory } from 'vue-router'
import Home from '../views/Home.vue'
import BookSearch from '../views/BookSearch.vue'
import AdminBooks from '../components/AdminBooks.vue'
import BookRecommendations from '../views/BookRecommendations.vue'
import BookDetail from '../views/BookDetail.vue'
import Login from '../components/Login.vue'

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/book-search',
    name: 'BookSearch',
    component: BookSearch
  },
  {
    path: '/book-search2',
    name: 'AdminBooks',
    component: AdminBooks
  },
  {
    path: '/book-recommendations',
    name: 'BookRecommendations',
    component: BookRecommendations
  },

  {
    path: '/book/:id',
    name: 'BookDetail',
    component: BookDetail
  },
  
  {
    path: '/login',  // URL 경로를 '/login'으로 수정하는 것이 일반적입니다.
    name: 'Login',
    component: () => import('../components/Login.vue') // 상대 경로로 수정
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
