const pagerouter = {
    path: "/",
    name: "layout",
    component: () => import("@/layout/index.vue"),
 },
export default pagerouter;