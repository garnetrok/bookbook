<template>
  <div class="book-detail">
    <div class="book-main-info">
      <img :src="book.image || defaultImage" :alt="book.title" class="book-image" />
      <div class="book-info">
        <h1 class="book-title">{{ book.title }}</h1>
        <div class="book-meta">
          <p class="book-author">{{ book.author }}</p>
          <span class="separator">|</span>
          <p class="book-publish">{{ book.publish }}</p>
        </div>
        <div class="book-categories">
          <span v-for="(category, index) in getKDCCategories" :key="index" class="kdc-category">
            {{ category }}
            <span v-if="index < getKDCCategories.length - 1" class="separator">></span>
          </span>
        </div>        <p class="isbn">{{ book.isbn }}</p>
        <div class="action-buttons">
          <button class="print-btn">
            <span class="icon">🖨️</span>
          </button>
          <button class="more-btn">
            <span class="icon">⋮</span>
          </button>
        </div>
      </div>
    </div>

    <!-- 도서 상세 정보 섹션 추가 -->
    <div class="book-detail-section">
      <div class="section-tabs">
        <button 
          class="tab-button" 
          :class="{ active: activeTab === 'description' }"
          @click="activeTab = 'description'"
        >
          도서 소개
        </button>
        <button 
          class="tab-button" 
          :class="{ active: activeTab === 'contents' }"
          @click="activeTab = 'contents'"
        >
          목차
        </button>
        <button 
          class="tab-button" 
          :class="{ active: activeTab === 'author' }"
          @click="activeTab = 'author'"
        >
          저자 소개
        </button>
      </div>

      <div class="section-content">
        <div v-if="activeTab === 'description'" class="description">
          <h3>도서 소개</h3>
          <p>{{ book.description || '도서 소개가 없습니다.' }}</p>
        </div>
        <div v-if="activeTab === 'contents'" class="contents">
          <h3>목차</h3>
          <p>{{ book.contents || '목차 정보가 없습니다.' }}</p>
        </div>
        <div v-if="activeTab === 'author'" class="author-info">
          <h3>저자 소개</h3>
          <p>{{ book.authorInfo || '저자 정보가 없습니다.' }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted } from 'vue';
import { useRoute } from 'vue-router';
import { fetchWithAuth } from '../util/fetchWithAuth';

export default {
  setup() {
    const route = useRoute();
    const book = ref({});
    const defaultImage = 'path/to/default/image.jpg';
    const activeTab = ref('description');

    // KDC Classification mapping
    const kdcClassification = {
      0: {
        name: '총류',
        subCategories: {
          0: '총류',
          1: '도서관,서지학',
          2: '문헌정보학',
          3: '백과사전',
          4: '강연집, 수필집, 연설문집',
          5: '일반 연속간행물',
          6: '일반학회, 단체, 협회, 기관',
          7: '신문, 언론, 저널리즘',
          8: '일반전집, 총서',
          9: '향토자료'
        }
      },
      1: {
        name: '철학',
        subCategories: {
          0: '철학',
          1: '형이상학',
          2: '인식론, 인과론, 인간학',
          3: '철학의 체계',
          4: '경학',
          5: '아시아철학,사상',
          6: '서양철학',
          7: '논리학',
          8: '심리학',
          9: '윤리학,도덕철학'
        }
      },
      // ... Add other main categories similarly ...
      9: {
        name: '역사',
        subCategories: {
          0: '역사',
          1: '아시아(아세아)',
          2: '유럽(구라파)',
          3: '아프리카',
          4: '북아메리카(북미)',
          5: '남아메리카(남미)',
          6: '오세아니아(대양주)',
          7: '양극지방',
          8: '지리',
          9: '전기'
        }
      }
    };

    const getKDCCategories = computed(() => {
      if (!book.value.code) return [];

      const code = book.value.code.toString().padStart(3, '0');
      const mainCategory = parseInt(code[0]);
      const subCategory = parseInt(code[1]);
      
      const categories = [];
      
      // Add main category
      if (kdcClassification[mainCategory]) {
        categories.push(kdcClassification[mainCategory].name);
      }
      
      // Add subcategory if exists
      if (kdcClassification[mainCategory]?.subCategories[subCategory]) {
        categories.push(kdcClassification[mainCategory].subCategories[subCategory]);
      }

      return categories;
    });

    const fetchBookDetails = async () => {
      const bookId = route.params.id;
      try {
        const response = await fetchWithAuth(`/admin/books/${bookId}`);
        if (!response.ok) {
          const text = await response.text();
          console.error('Error response:', text);
          throw new Error('Network response was not ok');
        }
        book.value = await response.json();
      } catch (error) {
        console.error('Error fetching book details:', error);
      }
    };

    onMounted(() => {
      fetchBookDetails();
    });

    return { 
      book, 
      defaultImage, 
      activeTab,
      getKDCCategories 
    };
  }
};
</script>


<style scoped>
.book-detail {
  margin: 2rem auto;
  max-width: 800px;
}

.book-main-info {
  display: flex;
  align-items: flex-start;
  background-color: white;
  border-radius: 12px;
  padding: 2rem;
  margin-bottom: 2rem;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
}

.book-image {
  width: 200px;
  height: auto;
  border-radius: 8px;
  margin-right: 2rem;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
  transition: transform 0.2s ease;
}

.book-image:hover {
  transform: scale(1.02);
}

.book-info {
  flex: 1;
  position: relative;
}

.book-title {
  font-size: 1.8rem;
  font-weight: 700;
  color: #333;
  margin-bottom: 1rem;
  line-height: 1.3;
}

.book-meta {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 1rem;
  color: #666;
}

.separator {
  color: #ddd;
}

.book-author {
  font-size: 1.1rem;
  margin: 0;
}

.book-publish {
  font-size: 1.1rem;
  margin: 0;
}

.book-categories {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 1rem;
  font-size: 0.9rem;
  color: #666;
}

.isbn {
  font-size: 0.9rem;
  color: #999;
  margin-top: 1rem;
}

/* 도서 상세 정보 섹션 스타일 */
.book-detail-section {
  background-color: white;
  border-radius: 12px;
  padding: 0;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
}

.section-tabs {
  display: flex;
  border-bottom: 1px solid #eee;
  padding: 0 2rem;
}

.tab-button {
  padding: 1rem 1.5rem;
  border: none;
  background: none;
  font-size: 1rem;
  color: #666;
  cursor: pointer;
  position: relative;
  transition: color 0.2s ease;
}

.tab-button.active {
  color: #333;
  font-weight: 600;
}

.tab-button.active::after {
  content: '';
  position: absolute;
  bottom: -1px;
  left: 0;
  width: 100%;
  height: 2px;
  background-color: #333;
}

.section-content {
  padding: 2rem;
}

.section-content h3 {
  font-size: 1.2rem;
  font-weight: 600;
  margin-bottom: 1rem;
  color: #333;
}

.section-content p {
  font-size: 1rem;
  line-height: 1.6;
  color: #666;
  white-space: pre-line;
}

.action-buttons {
  position: absolute;
  top: 0;
  right: 0;
  display: flex;
  gap: 0.5rem;
}

.action-buttons button {
  background: none;
  border: none;
  padding: 0.5rem;
  cursor: pointer;
  color: #666;
  transition: color 0.2s ease;
}

.action-buttons button:hover {
  color: #333;
}

.action-buttons .icon {
  font-size: 1.2rem;
}

@media (max-width: 640px) {
  .book-main-info {
    flex-direction: column;
    padding: 1rem;
  }

  .book-image {
    width: 150px;
    margin: 0 auto 1.5rem;
  }

  .book-info {
    padding: 0 0.5rem;
  }

  .book-title {
    font-size: 1.5rem;
    padding-right: 2.5rem;
  }

  .section-tabs {
    padding: 0 1rem;
    overflow-x: auto;
  }

  .tab-button {
    padding: 1rem;
    white-space: nowrap;
  }

  .section-content {
    padding: 1rem;
  }
}

.kdc-category {
  display: inline-flex;
  align-items: center;
  padding: 3px 6px;
  background-color: #f5f5f5;
  border-radius: 16px;
  font-size: 0.9rem;
  color: #666;
  margin-right: 4px;
  transition: background-color 0.2s, border-color 0.2s;
}

.kdc-category:hover {
  background-color: #e6e6e6;
  border-color: #c9c9c9;
}

.kdc-category .separator {
  margin: 0 4px;
  color: #999;
}
</style>