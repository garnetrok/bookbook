<template>
  <div class="book-recommendations">
    <h2 class="text-2xl font-semibold mb-6 text-gray-800">추천 도서</h2>

    <menu class="menu">
      <button 
        v-for="(keyword, index) in keywords" 
        :key="keyword.code"
        class="menu__item"
        :class="{ active: activeItem === index }"
        :style="{ '--bgColorItem': bgColors[index] }"
        @click="clickItem(index, keyword.code, books)"
      >
        <svg class="icon" viewBox="0 0 512 512">
          <path d="M284.1 298.4c-6.1 6.1-0.9 17.3-0.9 17.3l45.8 76.4c0 0 7.5 10.1 14 10.1 6.5 0 13-5.4 13-5.4l36.2-51.7c0 0 3.6-6.5 3.7-12.2 0.1-8.1-12.1-10.4-12.1-10.4l-85.7-27.5C298.1 294.9 289.7 292.7 284.1 298.4L284.1 298.4zM279.7 259.8c4.4 7.4 16.5 5.3 16.5 5.3l85.5-25c0 0 11.6-4.7 13.3-11.1 1.6-6.3-1.9-13.9-1.9-13.9L352.2 167c0 0-3.5-6.1-10.9-6.7 -8.1-0.7-13.1 9.1-13.1 9.1l-48.3 76C280 245.4 275.7 253 279.7 259.8L279.7 259.8zM239.4 230.2c10.1-2.5 11.7-17.1 11.7-17.1l-0.7-121.7c0 0-1.5-15-8.3-19.1 -10.6-6.4-13.7-3.1-16.7-2.6l-71 26.4c0 0-6.9 2.3-10.6 8.1 -5.2 8.2 5.3 20.2 5.3 20.2L222.8 225C222.8 225 230.1 232.5 239.4 230.2L239.4 230.2z" />
        </svg>
        <span class="menu__item-label">{{ keyword.label }}</span>
      </button>
      <div class="menu__border" ref="menuBorder"></div>
    </menu>
    <BookList :books="filteredBooks"/>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, watch } from 'vue';
import { useRouter } from 'vue-router'
import BookList from '../components/BookList.vue';
import { fetchWithAuth } from '../util/fetchWithAuth'

const books = ref([]);
const filteredBooks = ref([]);
const activeItem = ref(0);
const menuBorder = ref(null);
const router = useRouter();

const bgColors = ["#ffb457", "#ff96bd", "#9999fb", "#ffe797", "#cffff1", "#ff8c00", "#f54888", "#4343f5", "#e0b115", "#65ddb7"];

const keywords = [
  { label: '어린이', code: '100', range: [100, 199] },
  { label: '과학', code: '500', range: [500, 599] },
  { label: '역사', code: '900', range: [900, 999] },
  { label: '예술', code: '700', range: [700, 779] },
  { label: '음악', code: '780', range: [780, 799] },
  { label: '자연', code: '500', range: [500, 599] },
  { label: '수학', code: '400', range: [400, 499] },
  { label: '문학', code: '800', range: [800, 899] },
  { label: '판타지', code: '200', range: [200, 299] },
  { label: '탐험', code: '300', range: [300, 399] },
];

const fetchBooks = async () => {
  try {
    const response = await fetchWithAuth(`/admin/books`)
    if (response.ok) {
      const data = await response.json()
      books.value = data.content;
      filteredBooks.value = data.content; // Initially show all books
    } else {
      error.value = '책 목록을 불러오는 중 오류가 발생했습니다.'
    }
  } catch (error) {
    error.value = '네트워크 오류가 발생했습니다.'
  }
}

const offsetMenuBorder = (element, menuBorder) => {
  if (!element || !menuBorder) return;
  
  const offsetActiveItem = element.getBoundingClientRect();
  const left = Math.floor(
    offsetActiveItem.left - 
    element.parentElement.getBoundingClientRect().left - 
    (menuBorder.offsetWidth - offsetActiveItem.width) / 2
  ) + "px";
  
  menuBorder.style.transform = `translate3d(${left}, 0, 0)`;
};

const clickItem = (index, code) => {
  if (activeItem.value === index) return;
  activeItem.value = index;
  document.body.style.backgroundColor = bgColors[index];
  
  // Get the selected keyword's range
  const selectedKeyword = keywords[index];
  const [min, max] = selectedKeyword.range;
  
  // Filter books based on the code range
  filteredBooks.value = books.value.filter(book => {
    const bookCode = parseInt(book.code);
    return bookCode >= min && bookCode <= max;
  });
};

watch(activeItem, (newIndex) => {
  const menuItems = document.querySelectorAll('.menu__item');
  if (menuItems[newIndex] && menuBorder.value) {
    offsetMenuBorder(menuItems[newIndex], menuBorder.value);
  }
});

onMounted(() => {
  const firstMenuItem = document.querySelector('.menu__item');
  if (firstMenuItem && menuBorder.value) {
    offsetMenuBorder(firstMenuItem, menuBorder.value);
  }
  
  window.addEventListener('resize', () => {
    const activeMenuItem = document.querySelectorAll('.menu__item')[activeItem.value];
    if (activeMenuItem && menuBorder.value) {
      offsetMenuBorder(activeMenuItem, menuBorder.value);
    }
  });
});

onMounted(fetchBooks)
</script>



<style scoped>
.menu {
  margin: 0;
  display: flex;
  width: 32.05em;
  font-size: 1.5em;
  padding: 0 2.85em;
  position: relative;
  align-items: center;
  justify-content: center;
  background-color: #e0e0e0; /* Light gray bar */
  margin-bottom: 3rem;
  border-radius: 12px; /* Rounded edges */
}

.menu__item {
  all: unset;
  flex-grow: 1;
  z-index: 100;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  position: relative;
  border-radius: 50%;
  padding: 0.55em 0 0.85em;
  transition: transform var(--duration, 0.7s);
}

.menu__item::before {
  content: "";
  z-index: -1;
  width: 4.2em;
  height: 4.2em;
  border-radius: 50%;
  position: absolute;
  transform: scale(0);
  transition: background-color var(--duration, 0.7s), transform var(--duration, 0.7s);
}

.menu__item.active {
  transform: translate3d(0, -0.8em, 0);
}

.menu__item.active::before {
  transform: scale(1);
  background-color: var(--bgColorItem);
}

.icon {
  width: 2.6em;
  height: 2.6em;
  stroke: white;
  fill: transparent;
  stroke-width: 1pt;
  stroke-miterlimit: 10;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-dasharray: 400;
}

.menu__item.active .icon {
  animation: strok 1.5s reverse;
}

/* Adjusting the menu border to fit rounded bar and appear smoother */
.menu__border {
  left: 0;
  bottom: 80%;
  width: 8em;
  height: 2.4em;
  position: absolute;
  clip-path: path('M6.7,45.5c5.7,0.1,14.1-0.4,23.3-4c5.7-2.3,9.9-5,18.1-10.5c10.7-7.1,11.8-9.2,20.6-14.3c5-2.9,9.2-5.2,15.2-7c7.1-2.1,13.3-2.3,17.6-2.1c4.2-0.2,10.5,0.1,17.6,2.1c6.1,1.8,10.2,4.1,15.2,7c8.8,5,9.9,7.1,20.6,14.3c8.3,5.5,12.4,8.2,18.1,10.5c9.2,3.6,17.6,4.2,23.3,4H6.7z');
  background-color: #e0e0e0; /* Matching bar background */
  transition: transform var(--duration, 0.7s);
}

.menu__item-label {
  color: white;
  font-size: 0.7em;
  font-weight: 500;
  margin-top: 0.5em;
}

@media screen and (max-width: 50em) {
  .menu {
    font-size: 0.8em;
  }
}

@media screen and (max-width: 480px) {
  .menu {
    font-size: 0.7em;
    padding: 0 1.5em;
  }
}
</style>