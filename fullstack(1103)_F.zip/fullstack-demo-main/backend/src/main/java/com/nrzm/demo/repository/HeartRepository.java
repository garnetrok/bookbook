package com.nrzm.demo.repository;

import com.nrzm.demo.entity.Heart;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HeartRepository extends JpaRepository<Heart, Long> {
    Long findByIsbn(String isbn);
}
