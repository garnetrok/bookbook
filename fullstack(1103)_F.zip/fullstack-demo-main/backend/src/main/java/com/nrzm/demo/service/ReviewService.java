package com.nrzm.demo.service;

import com.nrzm.demo.entity.Review;
import com.nrzm.demo.repository.ReviewRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReviewService {

    private final ReviewRepository reviewRepository;

    public ReviewService(ReviewRepository reviewRepository) {
        this.reviewRepository = reviewRepository;
    }

    // 책 번호로 리뷰 목록 조회
    public List<Review> getReviewsByBookNo(Long bookNo) {
        return reviewRepository.findByBookNo(bookNo);  // findByBookNo로 변경
    }

    // 리뷰 저장
    public Review saveReview(Review review) {
        return reviewRepository.save(review);
    }

    // 리뷰 ID로 리뷰 조회
    public Review getReviewById(Long reviewId) {
        return reviewRepository.findById(reviewId).orElse(null);
    }

    // 리뷰 삭제
    public void deleteReview(Long reviewId) {
        reviewRepository.deleteById(reviewId);
    }
}
