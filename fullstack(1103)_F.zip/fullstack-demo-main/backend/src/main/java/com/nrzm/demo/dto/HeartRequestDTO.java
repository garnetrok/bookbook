package com.nrzm.demo.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class HeartRequestDTO {
    private String username;
    private Long bookId;
}
