package com.nrzm.demo.repository;

import com.nrzm.demo.entity.Review;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ReviewRepository extends JpaRepository<Review, Long> {
    // 특정 책에 대한 리뷰 목록 조회 (Book의 no 필드를 사용)
    List<Review> findByBookNo(Long bookNo);
}
