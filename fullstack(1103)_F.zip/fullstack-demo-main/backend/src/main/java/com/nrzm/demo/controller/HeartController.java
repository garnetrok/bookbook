package com.nrzm.demo.controller;

import com.nrzm.demo.dto.HeartRequestDTO;
import com.nrzm.demo.service.HeartService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class HeartController {
    private final HeartService heartService;

    @PostMapping("/admin/books/{bookId}/heart")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity addHeart(@AuthenticationPrincipal UserDetails userDetails, @PathVariable Long bookId) {
        HeartRequestDTO heartRequestDTO = heartService.addHeart(userDetails.getUsername(), bookId);
        //System.out.println("auth name : " + userDetails.getUsername());
        //System.out.println("book id : " + bookId);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/admin/books/{bookId}/heart")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity deleteHeart(@PathVariable Long bookId) {
        heartService.deleteHeart(bookId);
        return ResponseEntity.ok().build();
    }
}
