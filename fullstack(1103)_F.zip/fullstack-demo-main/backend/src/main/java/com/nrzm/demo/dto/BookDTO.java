package com.nrzm.demo.dto;

import jakarta.persistence.Column;

import java.time.LocalDate;

public class BookDTO {
    private int no;
    private String isbn;
    private String title;
    private String author;
    private String publish;
    private LocalDate date;
    private String image;
//    private String description;
//    private String contents;
//    private String authorInfo;
    private String code;

    // 기본 생성자
    public BookDTO() {}

    // 모든 필드를 포함한 생성자
    //public BookDTO(int no, String isbn, String title, String author, String publish, LocalDate date, String image, String description, String contents, String authorInfo, String code) {
    public BookDTO(int no, String isbn, String title, String author, String publish, LocalDate date, String image, String code) {
        this.no = no;
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.publish = publish;
        this.date = date;
        this.image = image;
    //    this.description = description;
    //    this.contents = contents;
    //    this.authorInfo = authorInfo;
        this.code = code;
    }

    // Getter와 Setter 메서드
    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPublish() { return publish; }

    public void setPublish(String publish) {
        this.publish = publish;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

//    public String getDescription() { return description; }
//    public void setDescription(String description) { this.description = publish;  }

//    public String getContents() { return contents; }
//    public void setContents(String contents) { this.contents = contents; }

//    public String getAuthorInfo() { return authorInfo; }
//    public void setAuthorInfo(String authorInfo) { this.authorInfo = authorInfo; }

    public String getCode() { return code; }

    public void setCode(String code) {
        this.code = code;
    }

    // toString 메서드 오버라이드
    @Override
    public String toString() {
        return "BookDTO{" +
                "no=" + no +
                ", isbn='" + isbn + '\'' +
                ", title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", publish='" + publish + '\'' +
                ", date=" + date + '\'' +
                ", image=" + image + '\'' +
              //  ", description='" + description + '\'' +
              //  ", contents='" + contents + '\'' +
              //  ", authorInfo='" + authorInfo + '\'' +
                ", code='" + code +
        '}';
    }
}