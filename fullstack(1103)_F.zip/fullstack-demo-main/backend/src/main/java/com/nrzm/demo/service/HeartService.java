package com.nrzm.demo.service;

import com.nrzm.demo.dto.HeartRequestDTO;
import com.nrzm.demo.entity.Book;
import com.nrzm.demo.entity.Heart;
import com.nrzm.demo.repository.BookRepository;
import com.nrzm.demo.repository.HeartRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class HeartService {
    private final HeartRepository heartRepository;
    private final BookRepository bookRepository;

    @Transactional
    public HeartRequestDTO addHeart(String username, Long bookId) {

        Optional<Book> book = bookRepository.findById(bookId);
        String isbn = book.map(Book::getIsbn).orElse(null);
        HeartRequestDTO heartRequestDTO = new HeartRequestDTO();

        Heart heart = Heart.builder()
                .username(username)
                .isbn(isbn)
                .build();

        heartRepository.save(heart);

        System.out.println("출력:" + heart);

        return heartRequestDTO;
    }

    @Transactional
    public void deleteHeart(Long bookId) {

        Optional<Book> book = bookRepository.findById(bookId);
        String isbn = book.map(Book::getIsbn).orElse(null);

        Long id = heartRepository.findByIsbn(isbn);

        heartRepository.deleteById(id);
    }
}
