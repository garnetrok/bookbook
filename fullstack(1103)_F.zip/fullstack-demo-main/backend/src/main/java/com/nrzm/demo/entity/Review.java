package com.nrzm.demo.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "reviews")  // 테이블 이름을 'reviews'로 변경
public class Review {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 255)
    private String content;

    @Column(nullable = false, length = 255)
    private String author;

    // `book_no`를 참조하여 `Book`과 ManyToOne 관계 설정
    @ManyToOne
    @JoinColumn(name = "book_no", nullable = false) // 외래키로 `book_no` 사용
    private Book book;  // 책 엔티티와의 관계를 설정

    // 기본 생성자
    public Review() {}

    // 생성자
    public Review(String content, String author, Book book) {
        this.content = content;
        this.author = author;
        this.book = book;
    }
}
