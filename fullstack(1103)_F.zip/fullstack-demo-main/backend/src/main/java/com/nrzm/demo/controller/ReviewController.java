package com.nrzm.demo.controller;

import com.nrzm.demo.entity.Review;
import com.nrzm.demo.service.ReviewService;
import com.nrzm.demo.entity.Book;
import com.nrzm.demo.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

@RestController
@RequestMapping("/api/books/{bookId}/reviews")
public class ReviewController {

    private static final Logger logger = LoggerFactory.getLogger(ReviewController.class);

    @Autowired
    private ReviewService reviewService;

    @Autowired
    private BookService bookService;

    // 리뷰 조회 (ADMIN 권한 필요)
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<Review>> getReviewsByBookId(@PathVariable Long bookId) {
        try {
            logger.info("Fetching reviews for bookId: {}", bookId);
            Book book = bookService.getBookById(bookId);
            if (book == null) {
                logger.warn("Book not found with id: {}", bookId);
                return ResponseEntity.notFound().build();
            }
            List<Review> reviews = reviewService.getReviewsByBookNo(bookId);
            return ResponseEntity.ok(reviews);
        } catch (Exception e) {
            logger.error("Error fetching reviews for bookId: {}", bookId, e);
            return ResponseEntity.status(500).build();
        }
    }

    // 리뷰 추가 (ADMIN 권한 필요)
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Review> addReview(@PathVariable Long bookId, @RequestBody Review review) {
        try {
            logger.info("Adding review for bookId: {}", bookId);
            Book book = bookService.getBookById(bookId);
            if (book == null) {
                logger.warn("Book not found with id: {}", bookId);
                return ResponseEntity.notFound().build();
            }
            review.setBook(book);
            Review savedReview = reviewService.saveReview(review);
            return ResponseEntity.status(201).body(savedReview);
        } catch (Exception e) {
            logger.error("Error adding review for bookId: {}", bookId, e);
            return ResponseEntity.status(500).build();
        }
    }

    // 리뷰 수정 (ADMIN 권한 필요)
    @PutMapping("/{reviewId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Review> updateReview(@PathVariable Long bookId, @PathVariable Long reviewId, @RequestBody Review updatedReview) {
        try {
            logger.info("Updating review for bookId: {}, reviewId: {}", bookId, reviewId);
            Review existingReview = reviewService.getReviewById(reviewId);
            if (existingReview == null || !existingReview.getBook().getNo().equals(bookId)) {
                logger.warn("Review or Book not found for reviewId: {} and bookId: {}", reviewId, bookId);
                return ResponseEntity.notFound().build();
            }
            existingReview.setContent(updatedReview.getContent());
            existingReview.setAuthor(updatedReview.getAuthor());
            Review savedReview = reviewService.saveReview(existingReview);
            return ResponseEntity.ok(savedReview);
        } catch (Exception e) {
            logger.error("Error updating review for reviewId: {}, bookId: {}", reviewId, bookId, e);
            return ResponseEntity.status(500).build();
        }
    }

    // 리뷰 삭제 (ADMIN 권한 필요)
    @DeleteMapping("/{reviewId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deleteReview(@PathVariable Long bookId, @PathVariable Long reviewId) {
        try {
            logger.info("Deleting review for bookId: {}, reviewId: {}", bookId, reviewId);
            Review existingReview = reviewService.getReviewById(reviewId);
            if (existingReview == null || !existingReview.getBook().getNo().equals(bookId)) {
                logger.warn("Review or Book not found for reviewId: {} and bookId: {}", reviewId, bookId);
                return ResponseEntity.notFound().build();
            }
            reviewService.deleteReview(reviewId);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            logger.error("Error deleting review for reviewId: {}, bookId: {}", reviewId, bookId, e);
            return ResponseEntity.status(500).build();
        }
    }
}
