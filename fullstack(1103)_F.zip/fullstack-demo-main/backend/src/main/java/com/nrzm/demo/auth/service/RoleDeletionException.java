package com.nrzm.demo.auth.service;

public class RoleDeletionException extends RuntimeException {
    public RoleDeletionException(String message) {
        super(message);
    }
}