<template>
  <div class="container mx-auto px-4 py-8">
    <RouterView />
  </div>
</template>
