<template>
  <div class="book-detail">
    
    <!-- 도서 정보 섹션 -->
    <div class="book-main-info">
      <img :src="book.image || defaultImage" :alt="book.title" class="book-image" />
      <div class="book-info">
        <h1 class="book-title">{{ book.title }}</h1>
        <div class="book-meta">
          <p class="book-author">{{ book.author }}</p>
          <span class="separator">|</span>
          <p class="book-publish">{{ book.publish }}</p>
        </div>
        <div class="book-categories" v-if="book.code">
        <span v-for="(category, index) in getKDCCategories" :key="index" class="kdc-category">
          {{ category.name }}
          <span v-if="index < getKDCCategories.length - 1" class="separator">&gt;</span>
        </span>
      </div>
        <div v-else class="loading-categories">
          카테고리 로딩 중...
        </div>

        <p class="isbn">{{ book.isbn }}</p>
        <div class="action-buttons">
          <!-- 하트 버튼 -->
          <button class="like-btn" @click="submitHeart">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 512 512"
              width="24"
              height="24"
              :class="{'liked': isLiked, 'beat': beatEffect}"
              @animationend="resetBeatEffect"
            >
              <path
                d="M47.6 300.4L228.3 469.1c7.5 7 17.4 10.9 27.7 10.9s20.2-3.9 27.7-10.9L464.4 300.4c30.4-28.3 47.6-68 47.6-109.5v-5.8c0-69.9-50.5-129.5-119.4-141C347 36.5 300.6 51.4 268 84L256 96 244 84c-32.6-32.6-79-47.5-124.6-39.9C50.5 55.6 0 115.2 0 185.1v5.8c0 41.5 17.2 81.2 47.6 109.5z"
                :fill="isLiked ? 'red' : 'black'"
              />
            </svg>
          </button>

        </div>
      </div>
    </div>

    <!-- 도서 상세 정보 섹션 추가 -->
    <div class="book-detail-section">
      <div class="section-tabs">
        <button 
          class="tab-button" 
          :class="{ active: activeTab === 'description' }"
          @click="activeTab = 'description'"
        >
          도서 소개
        </button>
        <button 
          class="tab-button" 
          :class="{ active: activeTab === 'contents' }"
          @click="activeTab = 'contents'"
        >
          목차
        </button>
        <button 
          class="tab-button" 
          :class="{ active: activeTab === 'author' }"
          @click="activeTab = 'author'"
        >
          저자 소개
        </button>
      </div>

      <div class="section-content">
        <div v-if="activeTab === 'description'" class="description">
          <h3>도서 소개</h3>
          <p>{{ book.description || '도서 소개가 없습니다.' }}</p>
        </div>
        <div v-if="activeTab === 'contents'" class="contents">
          <h3>목차</h3>
          <p>{{ book.contents || '목차 정보가 없습니다.' }}</p>
        </div>
        <div v-if="activeTab === 'author'" class="author-info">
          <h3>저자 소개</h3>
          <p>{{ book.authorinfo || '저자 정보가 없습니다.' }}</p>
        </div>
      </div>
    </div>


   
  </div>
</template>

<script>
import { ref, computed, onMounted, watch } from 'vue';
import { useRoute } from 'vue-router';
import { fetchWithAuth } from '../util/fetchWithAuth';

export default {
  setup() {
    
    const route = useRoute();
    const book = ref({});
    const defaultImage = 'path/to/default/image.jpg';
    const activeTab = ref('description');

    // 하트 버튼 관련 상태
    const isLiked = ref(false);
    const beatEffect = ref(false);
     

    // KDC Classification mapping
    const kdcClassification = {
      0: {
        name: '총류',
        subCategories: {
          0: '총류',
          1: '도서관,서지학',
          2: '문헌정보학',
          3: '백과사전',
          4: '강연집, 수필집, 연설문집',
          5: '일반 연속간행물',
          6: '일반학회, 단체, 협회, 기관',
          7: '신문, 언론, 저널리즘',
          8: '일반전집, 총서',
          9: '향토자료'
        }
      },
      1: {
        name: '철학',
        subCategories: {
          0: '철학',
          1: '형이상학',
          2: '인식론, 인과론, 인간학',
          3: '철학의 체계',
          4: '경학',
          5: '아시아철학,사상',
          6: '서양철학',
          7: '논리학',
          8: '심리학',
          9: '윤리학,도덕철학'
        }
      },
      2: {
        name: '종교',
        subCategories: {
          0: '종교',
          1: '불교',
          2: '기독교',
          3: '천주교',
          4: '이슬람교',
          5: '힌두교',
          6: '유대교',
          7: '기타 종교',
          8: '신화, 신비학',
          9: '종교학'
        }
      },
      3: {
        name: '사회과학',
        subCategories: {
          0: '사회과학',
          1: '통계학',
          2: '경제학',
          3: '정치학',
          4: '행정학',
          5: '법학',
          6: '사회학',
          7: '교육학',
          8: '풍속, 민속학',
          9: '국방, 군사학'
        }
      },
      4: {
        name: '자연과학',
        subCategories: {
          0: '자연과학',
          1: '수학',
          2: '물리학',
          3: '화학',
          4: '천문학',
          5: '지구과학',
          6: '생물학',
          7: '식물학',
          8: '동물학',
          9: '광물학'
        }
      },
      5: {
        name: '기술과학',
        subCategories: {
          0: '기술과학',
          1: '의학',
          2: '공학',
          3: '농업, 농학',
          4: '가정학, 가정과학',
          5: '환경학',
          6: '해양학',
          7: '산업공학',
          8: '건축학',
          9: '기타 기술과학'
        }
      },
      6: {
        name: '예술',
        subCategories: {
          0: '예술',
          1: '미술',
          2: '음악',
          3: '연극',
          4: '영화',
          5: '사진',
          6: '조각',
          7: '건축',
          8: '공예',
          9: '디자인'
        }
      },
      7: {
        name: '언어',
        subCategories: {
          0: '언어',
          1: '국어',
          2: '중국어',
          3: '영어',
          4: '독일어',
          5: '프랑스어',
          6: '스페인어',
          7: '일본어',
          8: '기타 외국어',
          9: '언어학'
        }
      },
      8: {
        name: '문학',
        subCategories: {
          0: '문학',
          1: '소설',
          2: '시',
          3: '희곡',
          4: '수필',
          5: '비평',
          6: '문예',
          7: '고전문학',
          8: '현대문학',
          9: '아동문학'
        }
      },
      9: {
        name: '역사',
        subCategories: {
          0: '역사',
          1: '아시아(아세아)',
          2: '유럽(구라파)',
          3: '아프리카',
          4: '북아메리카(북미)',
          5: '남아메리카(남미)',
          6: '오세아니아(대양주)',
          7: '양극지방',
          8: '지리',
          9: '전기'
        }
      }
    };

    watch(() => book.value, (newValue) => {
      if (newValue.code) {
        console.log('Book code updated:', newValue.code);
      }
    }, { deep: true });

    const getKDCCategories = computed(() => {
      if (!book.value?.code) return [];  // optional chaining 사용
      
      const code = book.value.code.toString().padStart(3, '0');
      console.log('Formatted code:', code);
      const mainCategory = parseInt(code[0]);
      const subCategory = parseInt(code[1]);
      
      const categories = [];
      
      if (kdcClassification[mainCategory]) {
        categories.push({
          code: mainCategory,
          name: kdcClassification[mainCategory].name
        });
        
        if (kdcClassification[mainCategory].subCategories[subCategory]) {
          categories.push({
            code: `${mainCategory}${subCategory}`,
            name: kdcClassification[mainCategory].subCategories[subCategory]
          });
        }
      }

      return categories;
    });
    
      const fetchBookDetails = async () => {
      const bookId = route.params.id;
      try {
        const response = await fetchWithAuth(`/admin/books/${bookId}`);
        if (!response.ok) {
          const text = await response.text();
          console.error('Error response:', text);
          throw new Error('Network response was not ok');
        }
        
        book.value = await response.json(); // JSON 데이터를 book.value에 할당
    
        

        // book.value가 정상적으로 로드된 후에 리뷰를 불러옴
        if (book.value && book.value.no) {
        //if (book.value && book.value.id) {
          console.log('book.value.no:', book.value.no);
          await fetchReviews(); // 도서 정보와 함께 리뷰 목록도 불러옴
        
        } else {
          console.error('도서 정보가 유효하지 않습니다.');
        }

      
      } catch (error) {
        console.error('Error fetching book details:', error);
      }
    };

    // 하트 버튼 관련 메서드
    const submitHeart = async () => {
      const response = await fetchWithAuth(`/admin/books/${book.value.no}/heart`, {
          method: 'POST',
      });
      if (response.ok) {
        isLiked.value = !isLiked.value; // Toggle like status
        beatEffect.value = true; // Start beat effect
      } else {
        console.error('좋아요 오류');
      }
    };

    const resetBeatEffect = () => {
      beatEffect.value = false; // 비트 효과 리셋
    };

    const newReview = ref(''); // 리뷰 입력 필드
    const review = ref([]); // 저장된 리뷰 목


    // 서버에서 리뷰 목록을 불러오는 함수
    const fetchReviews = async () => {
      try {
        const response = await fetchWithAuth(`/admin/books/${book.value.no}/reviews`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json'
          }
        });

        if (response.ok) {
          review.value = await response.json(); // 서버에서 받은 리뷰 목록
          console.log('review.value:', review.value);      
        } else {
          console.error('리뷰를 불러오는 중 오류가 발생했습니다.', response.status);
        }
      } catch (error) {
        console.error('리뷰를 불러오는 중 오류가 발생했습니다.', error);
      }
    };

  
      const submitReview = async () => {
  
      const reviewContent = newReview.value.trim();
      console.log('newReview.value:', reviewContent);

      if (!reviewContent) {
        alert('리뷰를 입력해주세요._에러');
        return;
      }


      if (newReview.value.trim()) {
        const username = sessionStorage.getItem("username");
        try {
          const response = await fetchWithAuth(`/api/books/${book.value.no}/reviews`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              content: newReview.value,
              author: username || 'admin'
            })
          });

          if (response.ok) {
            const savedReview = await response.json();
            review.value.push(savedReview);
            newReview.value = '';
          } else {
            console.error('리뷰 저장 중 오류가 발생했습니다.', response.status);
          }
        } catch (error) {
          console.error('리뷰 저장 중 오류가 발생했습니다:', error);
        }
      } else {
        alert('리뷰를 입력해주세요.');
      }
    };

    onMounted(() => {
      fetchBookDetails();
    });

    return { 
      book, 
      defaultImage, 
      activeTab,
      getKDCCategories,
      isLiked,
      beatEffect,
      submitHeart,
      resetBeatEffect 
    };
  }
};
</script>


<style scoped>
.book-detail {
  margin: 2rem auto;
  max-width: 800px;
}

.book-main-info {
  display: flex;
  align-items: flex-start;
  background-color: white;
  border-radius: 12px;
  padding: 2rem;
  margin-bottom: 2rem;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
}

.book-image {
  width: 200px;
  height: auto;
  border-radius: 8px;
  margin-right: 2rem;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
  transition: transform 0.2s ease;
}

.book-image:hover {
  transform: scale(1.02);
}

.book-info {
  flex: 1;
  position: relative;
}

.book-title {
  font-size: 1.8rem;
  font-weight: 700;
  color: #333;
  margin-bottom: 1rem;
  line-height: 1.3;
}

.book-meta {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 1rem;
  color: #666;
}

.separator {
  color: #ddd;
}

.book-author {
  font-size: 1.1rem;
  margin: 0;
}

.book-publish {
  font-size: 1.1rem;
  margin: 0;
}

.book-categories {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 1rem;
  font-size: 0.9rem;
  color: #666;
}

.isbn {
  font-size: 0.9rem;
  color: #999;
  margin-top: 1rem;
}

/* 도서 상세 정보 섹션 스타일 */
.book-detail-section {
  background-color: white;
  border-radius: 12px;
  padding: 0;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
}

.section-tabs {
  display: flex;
  border-bottom: 1px solid #eee;
  padding: 0 2rem;
}

.tab-button {
  padding: 1rem 1.5rem;
  border: none;
  background: none;
  font-size: 1rem;
  color: #666;
  cursor: pointer;
  position: relative;
  transition: color 0.2s ease;
}

.tab-button.active {
  color: #333;
  font-weight: 600;
}

.tab-button.active::after {
  content: '';
  position: absolute;
  bottom: -1px;
  left: 0;
  width: 100%;
  height: 2px;
  background-color: #333;
}

.section-content {
  padding: 2rem;
}

.section-content h3 {
  font-size: 1.2rem;
  font-weight: 600;
  margin-bottom: 1rem;
  color: #333;
}

.section-content p {
  font-size: 1rem;
  line-height: 1.6;
  color: #666;
  white-space: pre-line;
}

.action-buttons {
  position: absolute;
  top: 0;
  right: 0;
  display: flex;
  gap: 0.5rem;
}

.action-buttons button {
  background: none;
  border: none;
  padding: 0.5rem;
  cursor: pointer;
  color: #666;
  transition: color 0.2s ease;
}

.action-buttons button:hover {
  color: #333;
}

.action-buttons .icon {
  font-size: 1.2rem;
}

@media (max-width: 640px) {
  .book-main-info {
    flex-direction: column;
    padding: 1rem;
  }

  .book-image {
    width: 150px;
    margin: 0 auto 1.5rem;
  }

  .book-info {
    padding: 0 0.5rem;
  }

  .book-title {
    font-size: 1.5rem;
    padding-right: 2.5rem;
  }

  .section-tabs {
    padding: 0 1rem;
    overflow-x: auto;
  }

  .tab-button {
    padding: 1rem;
    white-space: nowrap;
  }

  .section-content {
    padding: 1rem;
  }
}

.kdc-category {
  display: inline-flex;
  align-items: center;
  padding: 3px 6px;
  background-color: #f5f5f5;
  border-radius: 16px;
  font-size: 0.9rem;
  color: #666;
  margin-right: 4px;
  transition: background-color 0.2s, border-color 0.2s;
}

.kdc-category:hover {
  background-color: #e6e6e6;
  border-color: #c9c9c9;
}

.kdc-category .separator {
  margin: 0 4px;
  color: #999;
}

.liked {
  animation: beat 0.2s;
}

@keyframes beat {
  0% { transform: scale(1); }
  50% { transform: scale(1.2); }
  100% { transform: scale(1); }
}

.action-buttons {
  display: flex;
  gap: 16px;
  margin-bottom: 16px;
}


/* 리뷰 등록 섹션 */
.review-section {
  background-color: white;
  border-radius: 12px;
  padding: 2rem;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
  margin-top: 2rem;
}

.review-section h2 {
  font-size: 1.5rem;
  font-weight: 700;
  color: #333;
  margin-bottom: 1.5rem;
}

.review-form {
  display: flex;
  flex-direction: column;
}

.review-form h3 {
  font-size: 1.2rem;
  font-weight: 600;
  color: #333;
  margin-bottom: 1rem;
}

.review-form textarea {
  width: 100%;
  font-size: 1rem;
  line-height: 1.4;
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 1rem;
  margin-bottom: 1rem;
  resize: vertical;
  color: #333;
}

.review-form button {
  align-self: flex-start;
  padding: 0.5rem 1rem;
  background-color: #007bff;
  color: white;
  font-size: 1rem;
  font-weight: 600;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.review-form button:hover {
  background-color: #0056b3;
}

.review-list {
  margin-top: 2rem;
}

.review-list h3 {
  font-size: 1.2rem;
  font-weight: 600;
  color: #333;
  margin-bottom: 1rem;
}

.review-list ul {
  list-style: none;
  padding: 0;
}

.review-list li {
  background-color: #f9f9f9;
  border-radius: 8px;
  padding: 1.5rem;
  margin-bottom: 1rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.review-list li p {
  font-size: 1rem;
  color: #333;
  margin-bottom: 0.5rem;
}

.review-list li .text-gray-500 {
  font-size: 0.875rem;
  color: #777;
}

</style>