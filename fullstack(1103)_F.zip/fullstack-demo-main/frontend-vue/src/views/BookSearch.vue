<!-- src/views/BookSearch.vue -->
<template>
  <div>
    <h1 class="text-2xl font-bold mb-4">도서 검색</h1>
    <SearchBar @search="handleSearch" />
    <BookList :books="paginatedItems" />

    <div v-if="filteredBooks.length === 0" class="text-center mt-4">
      검색 결과가 없습니다.
    </div>

    <Pagination 
      :current-page="currentPage" 
      :total-pages="totalPages"
      @page-change="goToPage" 
    />
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import SearchBar from '../components/SearchBar.vue';
import BookList from '../components/BookList.vue';
import Pagination, { usePagination } from '../components/Pagination.vue';
import { fetchWithAuth } from '../util/fetchWithAuth';

const books = ref([]);
const searchQuery = ref('');

// 필터링된 도서 목록
const filteredBooks = computed(() => {
  if (!searchQuery.value) {
    return books.value;
  }
  return books.value.filter(book => 
    book.title.includes(searchQuery.value)
  );
});

// 페이지네이션 로직 사용
const { 
  currentPage, 
  totalPages, 
  paginatedItems, 
  goToPage, 
  resetPagination 
} = usePagination(filteredBooks, 20); // 10은 itemsPerPage 값

// 검색어 처리 함수
const handleSearch = (query) => {
  searchQuery.value = query;
  resetPagination(); // 검색 시 첫 페이지로 리셋
};

// 초기 데이터 로드
onMounted(async () => {
  await fetchBooks();
});

const fetchBooks = async () => {
  const response = await fetchWithAuth('/admin/books');
  if (response.ok) {
    const data = await response.json();
    books.value = data.content;
  }
};
</script>