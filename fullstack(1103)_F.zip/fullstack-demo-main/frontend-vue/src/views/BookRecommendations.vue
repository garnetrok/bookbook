<template>
  <div class="book-recommendations">
    <h2 class="text-2xl font-semibold mb-6 text-gray-800">도서 분류</h2>

    <!-- Social Icon Container -->
    <ul class="soc">
      <li v-for="(keyword, index) in keywords" :key="keyword.code" class="menu-item">
        <button 
          class="menu__item" 
          :class="{ active: activeItem === index }" 
          :style="{ '--bgColorItem': bgColors[index] }" 
          @click="clickItem(index, keyword.code)">
          <svg class="icon w-6 h-6" viewBox="0 0 512 512">
            <path :d="iconPaths[index]" />
          </svg>
        </button>
        <!-- Label for the icon -->
        <span class="label text-lg text-gray-600 mt-1">{{ keyword.label }}</span>
      </li>
    </ul>

    <!-- BookList Component with paginatedBooks -->
    <BookList :books="paginatedItems" />
    <div v-if="filteredBooks.length === 0" class="text-center mt-4">검색 결과가 없습니다.</div>

    <Pagination :current-page="currentPage" :total-pages="totalPages" @page-change="goToPage" />
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, onBeforeUnmount, watch } from 'vue';
import { useRouter } from 'vue-router';
import BookList from '../components/BookList.vue';
import { fetchWithAuth } from '../util/fetchWithAuth';
import Pagination, { usePagination } from '../components/Pagination.vue';

const books = ref([]);
const searchQuery = ref('');
const filteredBooks = ref([]);
const activeItem = ref(0);
const menuBorder = ref(null);
const error = ref(null); // Define error state
const router = useRouter();
// 페이지네이션 로직 사용
const { 
  currentPage, 
  totalPages, 
  paginatedItems, 
  goToPage, 
  resetPagination 
} = usePagination(filteredBooks, 20); // 10은 itemsPerPage 값

const bgColors = [
  "#f8f9fa",  // Light Grey 1
  "#e9ecef",  // Light Grey 2
  "#dee2e6",  // Light Grey 3
  "#ced4da",  // Light Grey 4
  "#adb5bd",  // Grey 1
  "#6c757d",  // Grey 2
  "#495057",  // Dark Grey 1
  "#343a40",  // Dark Grey 2
  "#212529",  // Dark Grey 3
  "#f1f3f5"   // Lightest Grey
];


const iconPaths = [
  "M315.4 15.5C309.7 5.9 299.2 0 288 0s-21.7 5.9-27.4 15.5l-96 160c-5.9 9.9-6.1 22.2-.4 32.2s16.3 16.2 27.8 16.2l192 0c11.5 0 22.2-6.2 27.8-16.2s5.5-22.3-.4-32.2l-96-160zM288 312l0 144c0 22.1 17.9 40 40 40l144 0c22.1 0 40-17.9 40-40l0-144c0-22.1-17.9-40-40-40l-144 0c-22.1 0-40 17.9-40 40zM128 512a128 128 0 1 0 0-256 128 128 0 1 0 0 256z",
  "M156.6 384.9L125.7 354c-8.5-8.5-11.5-20.8-7.7-32.2c3-8.9 7-20.5 11.8-33.8L24 288c-8.6 0-16.6-4.6-20.9-12.1s-4.2-16.7 .2-24.1l52.5-88.5c13-21.9 36.5-35.3 61.9-35.3l82.3 0c2.4-4 4.8-7.7 7.2-11.3C289.1-4.1 411.1-8.1 483.9 5.3c11.6 2.1 20.6 11.2 22.8 22.8c13.4 72.9 9.3 194.8-111.4 276.7c-3.5 2.4-7.3 4.8-11.3 7.2l0 82.3c0 25.4-13.4 49-35.3 61.9l-88.5 52.5c-7.4 4.4-16.6 4.5-24.1 .2s-12.1-12.2-12.1-20.9l0-107.2c-14.1 4.9-26.4 8.9-35.7 11.9c-11.2 3.6-23.4 .5-31.8-7.8zM384 168a40 40 0 1 0 0-80 40 40 0 1 0 0 80z",
  "M240.1 4.2c9.8-5.6 21.9-5.6 31.8 0l171.8 98.1L448 104l0 .9 47.9 27.4c12.6 7.2 18.8 22 15.1 36s-16.4 23.8-30.9 23.8L32 192c-14.5 0-27.2-9.8-30.9-23.8s2.5-28.8 15.1-36L64 104.9l0-.9 4.4-1.6L240.1 4.2zM64 224l64 0 0 192 40 0 0-192 64 0 0 192 48 0 0-192 64 0 0 192 40 0 0-192 64 0 0 196.3c.6 .3 1.2 .7 1.8 1.1l48 32c11.7 7.8 17 22.4 12.9 35.9S494.1 512 480 512L32 512c-14.1 0-26.5-9.2-30.6-22.7s1.1-28.1 12.9-35.9l48-32c.6-.4 1.2-.7 1.8-1.1L64 224z",
  "M160 144c-35.3 0-64-28.7-64-64s28.7-64 64-64c15.7 0 30 5.6 41.2 15C212.4 12.4 232.7 0 256 0s43.6 12.4 54.8 31C322 21.6 336.3 16 352 16c35.3 0 64 28.7 64 64s-28.7 64-64 64c-14.7 0-28.3-5-39.1-13.3l-32 48C275.3 187 266 192 256 192s-19.3-5-24.9-13.3l-32-48C188.3 139 174.7 144 160 144zM144 352l48.4-24.2c10.2-5.1 21.6-7.8 33-7.8c19.6 0 38.4 7.8 52.2 21.6l32.5 32.5c6.3 6.3 14.9 9.9 23.8 9.9c11.3 0 21.8-5.6 28-15l9.7-14.6-58.9-66.3c-9.1-10.2-22.2-16.1-35.9-16.1l-41.8 0c-13.7 0-26.8 5.9-35.9 16.1l-59.9 67.4L144 352zm19.4-95.8c18.2-20.5 44.3-32.2 71.8-32.2l41.8 0c27.4 0 53.5 11.7 71.8 32.2l150.2 169c8.5 9.5 13.2 21.9 13.2 34.7c0 28.8-23.4 52.2-52.2 52.2L52.2 512C23.4 512 0 488.6 0 459.8c0-12.8 4.7-25.1 13.2-34.7l150.2-169z",
  "M272 96c-78.6 0-145.1 51.5-167.7 122.5c33.6-17 71.5-26.5 111.7-26.5l88 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-16 0-72 0s0 0 0 0c-16.6 0-32.7 1.9-48.3 5.4c-25.9 5.9-49.9 16.4-71.4 30.7c0 0 0 0 0 0C38.3 298.8 0 364.9 0 440l0 16c0 13.3 10.7 24 24 24s24-10.7 24-24l0-16c0-48.7 20.7-92.5 53.8-123.2C121.6 392.3 190.3 448 272 448l1 0c132.1-.7 239-130.9 239-291.4c0-42.6-7.5-83.1-21.1-119.6c-2.6-6.9-12.7-6.6-16.2-.1C455.9 72.1 418.7 96 376 96L272 96z",
  "M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zm50.7-186.9L162.4 380.6c-19.4 7.5-38.5-11.6-31-31l55.5-144.3c3.3-8.5 9.9-15.1 18.4-18.4l144.3-55.5c19.4-7.5 38.5 11.6 31 31L325.1 306.7c-3.2 8.5-9.9 15.1-18.4 18.4zM288 256a32 32 0 1 0 -64 0 32 32 0 1 0 64 0z",
  "M320 192l17.1 0c22.1 38.3 63.5 64 110.9 64c11 0 21.8-1.4 32-4l0 4 0 32 0 192c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-140.8L280 448l56 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-144 0c-53 0-96-43-96-96l0-223.5c0-16.1-12-29.8-28-31.8l-7.9-1c-17.5-2.2-30-18.2-27.8-35.7s18.2-30 35.7-27.8l7.9 1c48 6 84.1 46.8 84.1 95.3l0 85.3c34.4-51.7 93.2-85.8 160-85.8zm160 26.5s0 0 0 0c-10 3.5-20.8 5.5-32 5.5c-28.4 0-54-12.4-71.6-32c0 0 0 0 0 0c-3.7-4.1-7-8.5-9.9-13.2C357.3 164 352 146.6 352 128c0 0 0 0 0 0l0-96 0-20 0-1.3C352 4.8 356.7 .1 362.6 0l.2 0c3.3 0 6.4 1.6 8.4 4.2c0 0 0 0 0 .1L384 21.3l27.2 36.3L416 64l64 0 4.8-6.4L512 21.3 524.8 4.3c0 0 0 0 0-.1c2-2.6 5.1-4.2 8.4-4.2l.2 0C539.3 .1 544 4.8 544 10.7l0 1.3 0 20 0 96c0 17.3-4.6 33.6-12.6 47.6c-11.3 19.8-29.6 35.2-51.4 42.9zM432 128a16 16 0 1 0 -32 0 16 16 0 1 0 32 0zm48 16a16 16 0 1 0 0-32 16 16 0 1 0 0 32z",
  "M24 56c0-13.3 10.7-24 24-24l32 0c13.3 0 24 10.7 24 24l0 120 16 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-80 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l16 0 0-96-8 0C34.7 80 24 69.3 24 56zM86.7 341.2c-6.5-7.4-18.3-6.9-24 1.2L51.5 357.9c-7.7 10.8-22.7 13.3-33.5 5.6s-13.3-22.7-5.6-33.5l11.1-15.6c23.7-33.2 72.3-35.6 99.2-4.9c21.3 24.4 20.8 60.9-1.1 84.7L86.8 432l33.2 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-88 0c-9.5 0-18.2-5.6-22-14.4s-2.1-18.9 4.3-25.9l72-78c5.3-5.8 5.4-14.6 .3-20.5zM224 64l256 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-256 0c-17.7 0-32-14.3-32-32s14.3-32 32-32zm0 160l256 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-256 0c-17.7 0-32-14.3-32-32s14.3-32 32-32zm0 160l256 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-256 0c-17.7 0-32-14.3-32-32s14.3-32 32-32z",
  "M96 0C43 0 0 43 0 96L0 416c0 53 43 96 96 96l288 0 32 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l0-64c17.7 0 32-14.3 32-32l0-320c0-17.7-14.3-32-32-32L384 0 96 0zm0 384l256 0 0 64L96 448c-17.7 0-32-14.3-32-32s14.3-32 32-32zm32-240c0-8.8 7.2-16 16-16l192 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-192 0c-8.8 0-16-7.2-16-16zm16 48l192 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-192 0c-8.8 0-16-7.2-16-16s7.2-16 16-16z",
"M320 64c14.4 0 22.3-7 30.8-14.4C360.4 41.1 370.7 32 392 32c49.3 0 84.4 152.2 97.9 221.9C447.8 272.1 390.9 288 320 288s-127.8-15.9-169.9-34.1C163.6 184.2 198.7 32 248 32c21.3 0 31.6 9.1 41.2 17.6C297.7 57 305.6 64 320 64zM111.1 270.7c47.2 24.5 117.5 49.3 209 49.3s161.8-24.8 208.9-49.3c24.8-12.9 49.8-28.3 70.1-47.7c7.9-7.9 20.2-9.2 29.6-3.3c9.5 5.9 13.5 17.9 9.9 28.5c-13.5 37.7-38.4 72.3-66.1 100.6C523.7 398.9 443.6 448 320 448s-203.6-49.1-252.5-99.2C39.8 320.4 14.9 285.8 1.4 248.1c-3.6-10.6 .4-22.6 9.9-28.5c9.5-5.9 21.7-4.5 29.6 3.3c20.4 19.4 45.3 34.8 70.1 47.7z"
];

const keywords = [ 
  { label: '총류', code: '000', range: [0, 99] }, 
  { label: '철학', code: '100', range: [100, 199] }, 
  { label: '종교', code: '200', range: [200, 299] }, 
  { label: '사회과학', code: '300', range: [300, 399] }, 
  { label: '자연과학', code: '400', range: [400, 499] }, 
  { label: '기술과학', code: '500', range: [500, 599] }, 
  { label: '예술', code: '600', range: [600, 699] }, 
  { label: '언어', code: '700', range: [700, 799] }, 
  { label: '문학', code: '800', range: [800, 899] }, 
  { label: '역사', code: '900', range: [900, 999] }
];

// Fetch books from API
const fetchBooks = async () => {
  try {
    const response = await fetchWithAuth(`/admin/books`);
    if (response.ok) {
      const data = await response.json();
      books.value = data.content;
      filteredBooks.value = data.content; // Initially show all books
      error.value = null; // Reset error on successful fetch
    } else {
      error.value = '책 목록을 불러오는 중 오류가 발생했습니다.';
    }
  } catch (err) {
    error.value = '네트워크 오류가 발생했습니다.';
  }
};

const offsetMenuBorder = (element, menuBorder) => {
  if (!element || !menuBorder) return;

  const offsetActiveItem = element.getBoundingClientRect();
  const left = Math.floor(
    offsetActiveItem.left -
    element.parentElement.getBoundingClientRect().left -
    (menuBorder.offsetWidth - offsetActiveItem.width) / 2
  ) + "px";

  menuBorder.style.transform = `translate3d(${left}, 0, 0)`;
};

const clickItem = (index) => {
  if (activeItem.value === index) return;
  activeItem.value = index;
  document.body.style.backgroundColor = bgColors[index];

  // Get the selected keyword's range
  const selectedKeyword = keywords[index];
  const [min, max] = selectedKeyword.range;

  // Filter books based on the code range
  filteredBooks.value = books.value.filter(book => {
    const bookCode = parseInt(book.code);
    return bookCode >= min && bookCode <= max;
  });

  // 페이지 번호를 1로 초기화
  resetPagination(); // 페이지네이션 초기화
};

// Watch for changes in active item
watch(activeItem, (newIndex) => {
  const menuItems = document.querySelectorAll('.menu__item');
  if (menuItems[newIndex] && menuBorder.value) {
    offsetMenuBorder(menuItems[newIndex], menuBorder.value);
  }
});

// Set up menu border position on mount
onMounted(() => {
  const firstMenuItem = document.querySelector('.menu__item');
  if (firstMenuItem && menuBorder.value) {
    offsetMenuBorder(firstMenuItem, menuBorder.value);
  }
});

// Fetch books on component mount
fetchBooks();

</script>
<style scoped lang="scss">
$background: hsl(210, 45%, 10%);

html, body {
  background: $background;
}

.soc {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  list-style: none;
  margin: 2rem 0;
  padding: 0;
  max-width: 100%;
}

.soc li {
  margin: 0.8rem;
}

.menu__item {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 4.2em;
  height: 4.2em;
  border-radius: 50%;
  background-color: var(--bgColorItem, #e0e0e0);
  transition: transform 0.4s, box-shadow 0.3s, background-color 0.3s;
  cursor: pointer;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);  /* Default shadow */
  
  &:hover {
    transform: scale(1.3);
    box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);  /* Shadow on hover */
  }

  &.active {
    background-color: #ffffff;
  }
}

.icon {
  width: 2.5em;
  height: 2.5em;
  fill: #000000;
  stroke: #ffffff;
  stroke-width: 10pt;
  transition: stroke 0.3s, fill 0.3s;

  .menu__item.active & {
    fill: #ffffff;
    stroke: #000000;
  }

  .menu__item:hover & {
    fill: #ffffff;
  }
}

.label {
  display: block;  /* Ensures label takes full width */
  margin-top: 8px;  /* Space between icon and label */
  font-size: 1.125rem;  /* Larger font size (text-lg) */
  color: #4B5563;  /* Tailwind gray-600 */
  font-weight: 500;  /* Slightly bold for emphasis */
  text-align: center;  /* Center-aligns the label */
}

</style>
