<template>
  <footer class="bg-gray-800 text-white py-4"> <!-- 패딩을 py-4로 조정하여 크기 줄이기 -->
    <div class="container mx-auto text-center">
      <p>&copy; 2024 네이버 인공지능 웹개발 프로젝트 2조 '나의 책꽂이'</p>
    </div>
  </footer>
</template>

<script>
export default {
  name: 'Footer'
}
</script>

<style scoped>
/* 추가적인 푸터 스타일이 필요하면 여기에 작성하세요. */
</style>

