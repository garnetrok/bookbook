<template>
  <div class="container mx-auto flex flex-col items-center min-h-screen px-4 py-8">
    <div v-if="book" class="flex items-start space-x-8 mb-12">
      <img :src="book.image || defaultimage" alt="Book cover" class="cover-image" />
      <div>
        <h1 class="text-3xl font-bold mb-4">{{ book.title }}</h1>
        <p class="text-lg mb-2">저자: {{ book.author }}</p>
        <p class="text-lg mb-2">출판사: {{ book.publish }}</p>
        <p class="text-lg">ISBN: {{ book.isbn }}</p>
      </div>
    </div>
    <p v-else>도서 정보를 불러오는 중입니다...</p>

    <!-- 리뷰 작성 폼 -->
    <div v-if="book" class="w-full max-w-xl mt-6">
      <h2 class="text-2xl font-bold mb-4">리뷰 작성</h2>
      <textarea v-model="newReview" rows="4" class="w-full border border-gray-300 p-2 rounded mb-4" placeholder="리뷰를 입력하세요"></textarea>
      <button @click="submitReview" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded">리뷰 저장</button>

      <!-- 저장된 리뷰 목록 -->
      <div class="mt-8">
        <h2 class="text-2xl font-bold mb-4">리뷰 목록</h2>
        <ul>
          <li v-for="(review, index) in review" :key="index" class="bg-white shadow-md rounded-lg p-4 mb-4">
            <p>{{ review.content }}</p> <!-- 리뷰 내용 표시 -->
            <p class="text-gray-500 text-sm">작성자: {{ review.author }}</p> <!-- 작성자 표시 -->
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRoute } from 'vue-router';
import { fetchWithAuth } from '../util/fetchWithAuth';

const route = useRoute();
const book = ref(null);
const defaultimage = '/path/to/defaultimage.jpg';
const newReview = ref(''); // 리뷰 입력 필드
const review = ref([]); // 저장된 리뷰 목록

// 도서 상세 정보 가져오기
const fetchBookDetail = async () => {
  const bookNo = route.params.no; // URL에서 'no' 파라미터를 가져옴
  try {
    const response = await fetchWithAuth(`/admin/books/${bookNo}`);
    if (response.ok) {
      book.value = await response.json(); // 도서 정보를 제대로 book.value에 저장

      // book.value가 정상적으로 로드된 후에 리뷰를 불러옴
      if (book.value && book.value.no) {
        await fetchReviews(); // 도서 정보와 함께 리뷰 목록도 불러옴
      } else {
        console.error('도서 정보가 유효하지 않습니다.');
      }
    } else {
      console.error('도서 정보를 불러오는 중 오류가 발생했습니다.');
    }
  } catch (error) {
    console.error('네트워크 오류:', error);
  }
};

// 서버에서 리뷰 목록을 불러오는 함수
const fetchReviews = async () => {
  try {
    const response = await fetchWithAuth(`/api/books/${book.value.no}/reviews`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    });

    if (response.ok) {
      review.value = await response.json(); // 서버에서 받은 리뷰 목록
    } else {
      console.error('리뷰를 불러오는 중 오류가 발생했습니다.', response.status);
    }
  } catch (error) {
    console.error('리뷰를 불러오는 중 오류가 발생했습니다.', error);
  }
};

// 리뷰 저장 로직에서 작성자 정보가 로그인된 사용자로부터 동적으로 가져오는 방식
const submitReview = async () => {
  if (newReview.value.trim()) {
    const username = sessionStorage.getItem("username"); // 사용자 이름 저장

    try {
      const response = await fetchWithAuth(`/api/books/${book.value.no}/reviews`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          content: newReview.value, // 리뷰 내용
          author: username || 'admin'//'알 수 없는 사용자' // 사용자 이름을 동적으로 가져옴
        })
      });

      if (response.ok) {
        const savedReview = await response.json();
        review.value.push(savedReview); // 성공적으로 저장된 리뷰를 목록에 추가
        newReview.value = ''; // 입력 필드 초기화
      } else {
        console.error('리뷰 저장 중 오류가 발생했습니다.', response.status);
      }
    } catch (error) {
      console.error('리뷰 저장 중 오류가 발생했습니다.', error);
    }
  } else {
    alert('리뷰를 입력해주세요.');
  }
};

onMounted(fetchBookDetail);
</script>

<style scoped>
.cover-image {
  max-width: 300px;
  height: auto;
  margin-right: 2rem;
}
.container {
  display: flex;
  align-items: flex-start;
  justify-content: center;
}
</style>
