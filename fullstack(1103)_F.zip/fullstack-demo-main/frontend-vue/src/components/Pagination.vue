<template>
    <div class="pagination" v-if="totalPages > 1">
      <button 
        v-if="currentPage > 0" 
        @click="goToPage(currentPage - 1)"
        class="pagination-button"
      >
        <!-- Previous page SVG -->
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" class="w-4 h-4 inline">
          <path d="M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l192 192c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L77.3 256 246.6 86.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-192 192z"/>
        </svg>
      </button>
      
      <span class="page-info">
        페이지 <strong>{{ currentPage + 1 }}</strong> / <strong>{{ totalPages }}</strong>
      </span>
  
      <button 
        v-if="currentPage < totalPages - 1" 
        @click="goToPage(currentPage + 1)"
        class="pagination-button"
      >
        <!-- Next page SVG -->
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" class="w-4 h-4 inline">
          <path d="M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z"/>
        </svg>
      </button>
    </div>
  </template>
  
  <script>
  import { ref, computed } from 'vue';
  
  // Pagination 로직을 위한 composable
  export function usePagination(items, itemsPerPage = 28) { // Change default to 9
    const currentPage = ref(0);
    const totalItems = computed(() => items.value?.length || 0);
    const totalPages = computed(() => Math.ceil(totalItems.value / itemsPerPage));

    const paginatedItems = computed(() => {
        const start = currentPage.value * itemsPerPage;
        const end = start + itemsPerPage;
        return items.value?.slice(start, end) || [];
    });

    const goToPage = (page) => {
        if (page >= 0 && page < totalPages.value) {
            currentPage.value = page;
        }
    };

    const resetPagination = () => {
        currentPage.value = 0;
    };

    return {
        currentPage,
        totalPages,
        paginatedItems,
        goToPage,
        resetPagination
    };
}
  
  export default {
      name: 'Pagination',
      props: {
          currentPage: {
              type: Number,
              required: true
          },
          totalPages: {
              type: Number,
              required: true
          }
      },
      emits: ['page-change'],
      setup(props, { emit }) {
          const goToPage = (newPage) => {
              emit('page-change', newPage);
          };
  
          return {
              goToPage
          };
      }
  };
  </script>
  
  <style scoped>
  .pagination {
      display: flex;
      justify-content: center;
      align-items: center;
      margin-top: 20px;
  }
  
  .pagination-button {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background-color: #f9f9f9; /* Tailwind gray-100 */
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      cursor: pointer;
      transition: background-color 0.3s ease, box-shadow 0.3s ease;
  }
  
  .pagination-button:hover {
      background-color: #ebebeb; /* Tailwind gray-200 */
      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
  }
  
  .page-info {
      height: auto; 
      margin: 0 15px;
      font-size: 16px; /* 텍스트 크기 조절 */
      font-weight: 600; /* 볼드 스타일 */
      color: #4a5568; /* 텍스트 색상 */
  }
  
  .pagination-button:disabled {
      background-color: #edf2f7; /* Tailwind gray-100 */
      cursor: not-allowed;
      box-shadow: none;
  }
  </style>
  