<template>
  <header class="bg-blue-800 text-white p-6">
    <div class="container mx-auto flex justify-between items-center">
      <router-link to="/" class="text-3xl font-bold">나의 책꽂이</router-link>
      <nav>
        <router-link to="/book-search" class="mx-4 text-white hover:text-yellow-300">도서 검색</router-link>
        <router-link to="/book-search2" class="mx-4 text-white hover:text-yellow-300">독서 활동</router-link> 
        <router-link to="/book-recommendations" class="mx-4 text-white hover:text-yellow-300">도서 분류</router-link>

        <!-- 로그인 상태에 따라 로그인/로그아웃 버튼 표시 -->
        <button v-if="isLoggedIn" @click="handleLogout" class="mx-4 text-white hover:text-yellow-300">로그아웃</button>
        <router-link v-else to="/login" class="mx-4 text-white hover:text-yellow-300">로그인</router-link>
      </nav>
    </div>
  </header>
</template>

<script>
export default {
  name: 'Header',
  data() {
    return {
      isLoggedIn: false  // 로그인 여부를 저장하는 변수
    };
  },
  methods: {
    checkLoginStatus() {
      // sessionStorage에서 accessToken을 확인해 로그인 상태 설정
      const token = sessionStorage.getItem('accessToken');
      this.isLoggedIn = !!token;  // 토큰이 있으면 true, 없으면 false
    },
    handleLogout() {
      // 로그아웃 처리: 세션에서 토큰 삭제 및 로그인 상태 업데이트
      sessionStorage.removeItem('accessToken');  // 세션에서 토큰 삭제
      this.isLoggedIn = false;  // 로그인 상태를 false로 업데이트
      this.$router.push('/login');  // 로그인 페이지로 리다이렉트
    }
  },
  mounted() {
    // 페이지 로드 시 로그인 상태 확인
    this.checkLoginStatus();

    // 로그인 상태를 지속적으로 확인하기 위해 setInterval 사용 (선택 사항)
    setInterval(() => {
      this.checkLoginStatus();
    }, 1000);  // 1초마다 상태 확인
  },
  updated() {
    // 로그인 페이지에서 로그인 후 상태 즉시 반영
    this.checkLoginStatus();
  }
};
</script>

<style scoped>
/* 헤더 스타일 */
</style>
