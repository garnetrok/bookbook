<template>
  <nav class="bg-blue-600 text-white p-4">
    <ul class="flex justify-center space-x-6">
      <li><router-link to="/" class="hover:text-yellow-300">메인</router-link></li>
      <li><router-link to="/booksearch" class="hover:text-yellow-300">도서검색</router-link></li>
      <li><router-link to="/recommendations" class="hover:text-yellow-300">도서분류</router-link></li>
      <li><router-link to="/admin" class="hover:text-yellow-300">관리자 로그인</router-link></li>
      
      <!-- Authentication Conditional Rendering -->
      <li v-if="isAuth" class="my-2 md:my-0">
        <Logout
          class="flex items-center text-blue-600 hover:bg-blue-100 hover:text-blue-800 px-3 py-2 rounded-md transition duration-300 ease-in-out"
          @updateAuth="updateAuth">
          <ArrowLeftStartOnRectangleIcon class="w-5 h-5 mr-2" />
          로그아웃
        </Logout>
      </li>

      <li v-else class="my-2 md:my-0">
        <router-link to="/pages/login"
          class="flex items-center text-blue-600 hover:bg-blue-100 hover:text-blue-800 px-3 py-2 rounded-md transition duration-300 ease-in-out">
          <ArrowLeftEndOnRectangleIcon class="w-5 h-5 mr-2" />
          로그인
        </router-link>
      </li>
    </ul>
  </nav>
</template>

<script>
import Logout from './Logout.vue'  // Logout 컴포넌트 import

export default {
  name: 'NavLinks',
  props: {
    isAuth: Boolean,
  },
  emits: ['updateAuth'],
  methods: {
    updateAuth(newValue) {
      this.$emit('updateAuth', newValue)
    }
  }
}
</script>
