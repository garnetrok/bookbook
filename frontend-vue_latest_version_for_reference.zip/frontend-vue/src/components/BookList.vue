<template>
    <div class="book-list">
      <div class="book-container" ref="bookContainer">
        <BookCard v-for="book in books" :key="book.id" :book="book" />
      </div>
    </div>
  </template>
  
  <script>
  import BookCard from './BookCard.vue';
  
  export default {
    name: 'BookList',
    components: {
      BookCard
    },
    props: {
      books: {
        type: Array,
        required: true
      }
    }
  }
  </script>
  
  <style scoped>
  .book-list {
    position: relative;
    overflow: hidden; /* Prevent overflow of the container */
  }
  
  .book-container {
    display: flex; /* Use flexbox for horizontal layout */
    flex-wrap: wrap; /* Allow items to wrap onto multiple lines */
    padding: 10px 0; /* Add some vertical padding */
    gap: 10px; /* Add space between cards */
  }
  
  /* Optional: Hide scrollbar for a cleaner look */
  .book-container::-webkit-scrollbar {
    display: none; /* Hide scrollbar */
  }
  
  /* Ensure that the BookCards are displayed inline */
  .book-container > * {
    flex: 1 1 200px; /* Allow items to grow and shrink, with a minimum width */
    /* This allows the cards to adjust based on screen size */
  }
  </style>
  