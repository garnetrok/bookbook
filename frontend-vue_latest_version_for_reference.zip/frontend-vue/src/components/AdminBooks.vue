<template>
  <div class="container mx-auto px-4 py-8 max-w-6xl">
    <h1 class="text-3xl font-bold mb-6">도서목록</h1>
    <SearchBar @search="handleSearch" />
    <p v-if="error" class="text-red-500 mb-4">{{ error }}</p>
    <div class="overflow-x-auto">
      <ul class="flex flex-nowrap gap-4 pb-4">
        <li v-for="book in books" :key="book.no" class="flex-shrink-0 w-80 bg-white shadow-md rounded-lg p-4">
          <template v-if="editBook && editBook.no === book.no">
          </template>
          <template v-else>
            <div class="mb-4" @click="goToDetail(book.no)">
              <img :src="book.image || defaultimage" :alt="book.title" class="cover-image" />              
              <h3 class="font-bold text-lg">{{ book.title }}</h3>
              <p class="text-sm text-gray-600">저자: {{ book.author }}</p>
              <p class="text-sm text-gray-600">출판사: {{ book.publish }}</p>
              <p class="text-sm text-gray-600">isbn: {{ book.isbn }}</p>
            </div>
            <div class="flex justify-end space-x-2">
              <button @click="searchLib(book)"
                class="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-1 px-2 rounded text-sm">
                소장 도서관 조회
              </button>
            </div>

            <!-- 소장 도서관 결과 출력 -->
            <div v-if="book.libraryData && book.libraryData.length > 0" class="mt-4">
              <h4 class="font-bold text-md">소장 도서관 목록:</h4>
              <ul class="max-h-40 overflow-y-auto">
                <li v-for="item in book.libraryData" :key="item.lib.libCode" class="text-sm text-gray-600">
                  {{ item.lib.libName }}
                </li>
              </ul>
            </div>
            <div v-else-if="book.libraryData && book.libraryData.length === 0" class="mt-4 text-sm text-gray-600">
              소장 도서관이 없습니다.
            </div>
            <div v-else-if="book.isSearching" class="mt-4 text-sm text-gray-600">
              도서관 정보를 조회 중입니다...
            </div>
          </template>
        </li>
      </ul>
    </div>

    <div class="flex justify-center items-center mt-6">
      <button @click="prevPage" :disabled="currentPage === 0"
        class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded-l disabled:opacity-50">
        이전
      </button>
      <span class="px-4">
        {{ currentPage + 1 }} / {{ totalPages }}
      </span>
      <button @click="nextPage" :disabled="currentPage === totalPages - 1"
        class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded-r disabled:opacity-50">
        다음
      </button>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { fetchWithAuth } from '../util/fetchWithAuth'
import { useRouter } from 'vue-router'
import SearchBar from '../components/SearchBar.vue'

import axios from 'axios';

const books = ref([])
const loading = ref(true)
const error = ref('')
const newBook = reactive({
  no: '',
  isbn: '',
  title: '',
  author: '',
  publish: '',
  date: '',
  image: ''
})
const editBook = ref(null)
const currentPage = ref(0)
const totalPages = ref(0)

const router = useRouter();

const goToDetail = (bookNo) => {
  router.push({ name: 'BookDetail', params: { no: bookNo } });
};

const fetchBooks = async () => {
  try {
    const response = await fetchWithAuth(`/admin/books?page=${currentPage.value}&size=3`)
    if (response.ok) {
      const data = await response.json()
      books.value = data.content
      totalPages.value = data.totalPages
    } else {
      error.value = '책 목록을 불러오는 중 오류가 발생했습니다.'
    }
  } catch (err) {
    error.value = '네트워크 오류가 발생했습니다.1'
  }
}

const libraryData = ref([]);

const searchLib = async (book) => {
  if (book.libraryData) return;
  
  book.isSearching = true;
  try {
    const response = await fetchWithAuth(`/api/search/book?isbn=${book.isbn}&region=29`, {
      method: 'GET'
    })

    const lib = await response.json();

    if (response.ok) {
      book.libraryData = lib.response.libs;
    } else {
      console.error('API 응답 구조가 예상과 다릅니다:', response);
      error.value = '소장 도서관 정보를 불러오는데 실패했습니다.';
      book.libraryData = [];
    }
  } catch (error) {
    console.error('소장 도서관을 조회하는 중 오류가 발생했습니다.', error);
    error.value = '소장 도서관 조회 중 오류가 발생했습니다.';
    book.libraryData = [];
  } finally {
    book.isSearching = false;
  }
};

const prevPage = () => {
  if (currentPage.value > 0) {
    currentPage.value -= 1
    fetchBooks()
  }
}

const nextPage = () => {
  if (currentPage.value < totalPages.value - 1) {
    currentPage.value += 1
    fetchBooks()
  }
}

const handleSearch = async (query) => {
  if (query) {
    const response = await fetchWithAuth(`/admin/books?search=${query}&page=0&size=3`);
    if (response.ok) {
      const data = await response.json();
      books.value = data.content;
      totalPages.value = data.totalPages;
      currentPage.value = 0;
    } else {
      error.value = '검색 중 오류가 발생했습니다.';
    }
  } else {
    currentPage.value = 0;
    await fetchBooks();
  }
}

onMounted(fetchBooks)
</script>

<style scoped>
/* TailwindCSS styles used */
</style>