package com.nrzm.demo.dto;

import java.time.LocalDate;

public class BookDTO {
    private int no;
    private String isbn;
    private String title;
    private String author;
    private String publish;
    private LocalDate date;

    // 기본 생성자
    public BookDTO() {}

    // 모든 필드를 포함한 생성자
    public BookDTO(int no, String isbn, String title, String author, String publish, LocalDate date) {
        this.no = no;
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.publish = publish;
        this.date = date;
    }

    // Getter와 Setter 메서드
    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPublish() {
        return publish;
    }

    public void setPublish(String publish) {
        this.publish = publish;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    // toString 메서드 오버라이드
    @Override
    public String toString() {
        return "BookDTO{" +
                "no=" + no +
                ", isbn='" + isbn + '\'' +
                ", title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", publish='" + publish + '\'' +
                ", date=" + date +
                '}';
    }
}