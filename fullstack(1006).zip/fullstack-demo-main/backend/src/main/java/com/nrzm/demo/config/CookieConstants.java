package com.nrzm.demo.config;

public class CookieConstants {
    public static final String REFRESH_TOKEN_PREFIX = "refreshToken-";
}