<template>
  <div>
    <h1>책 검색</h1>
    <form @submit.prevent="searchBook">
      <div>
        <label for="isbn">ISBN</label>
        <input v-model="isbn" id="isbn" type="text" required />
      </div>
      <div>
        <label for="region">Region</label>
        <input v-model="region" id="region" type="text" />
      </div>
      <button type="submit">검색</button>
    </form>

    <!-- 결과를 보여줄 영역 -->
    <div v-if="bookData">
      <h2>검색 결과</h2>
      <pre>{{ bookData }}</pre> <!-- JSON 형식으로 출력 -->
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      isbn: '',     // ISBN 입력값
      region: '29', // 지역 입력값 (기본값: 29)
      bookData: null, // API로 받은 데이터 저장
    };
  },
  methods: {
    async searchBook() {
      try {
        const response = await axios.get('http://localhost:8080/2api/search/book', {
          params: {
            isbn: this.isbn,
            region: this.region
          }
        });
        this.bookData = response.data; // API 응답 데이터 저장
      } catch (error) {
        console.error('책 검색 중 오류 발생:', error);
      }
    }
  }
};
</script>
