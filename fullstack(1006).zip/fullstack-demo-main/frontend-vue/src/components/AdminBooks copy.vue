<template>
  <div class="container mx-auto px-4 py-8 max-w-6xl">
    <h1 class="text-3xl font-bold mb-6">도서 관리</h1>
    <p v-if="error" class="text-red-500 mb-4">{{ error }}</p>
    <form @submit.prevent="handleAddBook" class="mb-8 bg-white shadow-md rounded px-8 pt-6 pb-8">
      <div class="mb-4 flex flex-wrap -mx-2">
        <div class="w-full md:w-1/2 px-2 mb-4 md:mb-0">
          <label class="block text-gray-700 text-sm font-bold mb-2" for="no">
            도서 번호
          </label>
          <input v-model="newBook.no"
            class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="no" type="text" required autocomplete="off">
        </div>
        <div class="w-full md:w-1/2 px-2">
          <label class="block text-gray-700 text-sm font-bold mb-2" for="isbn">
            ISBN
          </label>
          <input v-model="newBook.isbn"
            class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="isbn" type="text" required autocomplete="off">
        </div>
      </div>
      <div class="mb-4">
        <label class="block text-gray-700 text-sm font-bold mb-2" for="title">
          제목
        </label>
        <input v-model="newBook.title"
          class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          id="title" type="text" required autocomplete="off">
      </div>
      <div class="mb-4">
        <label class="block text-gray-700 text-sm font-bold mb-2" for="author">
          저자
        </label>
        <input v-model="newBook.author"
          class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          id="author" type="text" required autocomplete="off">
      </div>
      <div class="mb-4">
        <label class="block text-gray-700 text-sm font-bold mb-2" for="publish">
          출판사
        </label>
        <input v-model="newBook.publish"
          class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          id="publish" type="text" required autocomplete="off">
      </div>
      <div class="mb-4">
        <label class="block text-gray-700 text-sm font-bold mb-2" for="date">
          출판일
        </label>
        <input v-model="newBook.date"
          class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
          id="date" type="date" required autocomplete="off">
      </div>
      <div class="flex items-center justify-between">
        <button
          class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
          type="submit">
          도서 추가
        </button>
      </div>
    </form>
    <div class="overflow-x-auto">
      <ul class="flex flex-nowrap gap-4 pb-4">
        <li v-for="book in books" :key="book.no" class="flex-shrink-0 w-80 bg-white shadow-md rounded-lg p-4">
          <template v-if="editBook && editBook.no === book.no">
            <form @submit.prevent="handleEditBookSubmit" class="space-y-4">
              <div>
                <label for="edit-title" class="block text-sm font-medium text-gray-700">제목</label>
                <input id="edit-title" v-model="editBook.title" type="text"
                  class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  required autocomplete="off">
              </div>
              <div>
                <label for="edit-author" class="block text-sm font-medium text-gray-700">저자</label>
                <input id="edit-author" v-model="editBook.author" type="text"
                  class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  required autocomplete="off">
              </div>
              <div>
                <label for="edit-publish" class="block text-sm font-medium text-gray-700">출판사</label>
                <input id="edit-publish" v-model="editBook.publish" type="text"
                  class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  required autocomplete="off">
              </div>
              <div>
                <label for="edit-date" class="block text-sm font-medium text-gray-700">출판일</label>
                <input id="edit-date" v-model="editBook.date" type="date"
                  class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  required autocomplete="off">
              </div>
              <div class="flex justify-end space-x-2">
                <button type="submit"
                  class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50">
                  저장
                </button>
                <button type="button" @click="cancelEdit"
                  class="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-opacity-50">
                  취소
                </button>
              </div>
            </form>
          </template>
          <template v-else>
            <div class="mb-4">
              <h3 class="font-bold text-lg">{{ book.title }}</h3>
              <p class="text-sm text-gray-600">저자: {{ book.author }}</p>
              <p class="text-sm text-gray-600">출판사: {{ book.publish }}</p>
              <p class="text-sm text-gray-600">출판일: {{ book.date }}</p>
              <p class="text-sm text-gray-600">isbn: {{ book.isbn }}</p>
            </div>
            <div class="flex justify-end space-x-2">
              <button @click="searchLib(book)"
                class="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-1 px-2 rounded text-sm">
                소장 도서관 조회
              </button>
              <button @click="setEditBook(book)"
                class="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-1 px-2 rounded text-sm">
                수정
              </button>
              <button @click="handleDeleteBook(book.no)"
                class="bg-red-500 hover:bg-red-600 text-white font-bold py-1 px-2 rounded text-sm">
                삭제
              </button>
            </div>


            <!-- 소장 도서관 결과 출력 -->
            <div v-if="libraryData.length > 0" class="mt-4">
              <h4 class="font-bold text-md">소장 도서관 목록:</h4>
              <ul>
                <li v-for="item in libraryData" :key="item.lib.libCode" class="text-sm text-gray-600">
                  {{ item.lib.libName }} <!-- ({{ item.lib.address }})-->
                </li>
              </ul>
            </div>

          </template>
        </li>
      </ul>
    </div>
    <div class="flex justify-center items-center mt-6">
      <button @click="prevPage" :disabled="currentPage === 0"
        class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded-l disabled:opacity-50">
        이전
      </button>
      <span class="px-4">
        {{ currentPage + 1 }} / {{ totalPages }}
      </span>
      <button @click="nextPage" :disabled="currentPage === totalPages - 1"
        class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded-r disabled:opacity-50">
        다음
      </button>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { fetchWithAuth } from '../util/fetchWithAuth'

import axios from 'axios';

const books = ref([])
const loading = ref(true)
const error = ref('')
const newBook = reactive({
  no: '',
  isbn: '',
  title: '',
  author: '',
  publish: '',
  date: ''
})
const editBook = ref(null)
const currentPage = ref(0)
const totalPages = ref(0)

const fetchBooks = async () => {
  try {
    const response = await fetchWithAuth(`/admin/books?page=${currentPage.value}&size=5`)
    if (response.ok) {
      const data = await response.json()
      books.value = data.content
      totalPages.value = data.totalPages
                } else {
      error.value = '책 목록을 불러오는 중 오류가 발생했습니다.'
    }
  } catch (err) {
    error.value = '네트워크 오류가 발생했습니다.1'
  }
}



const libraryData = ref([]); // 배열로 초기화

const searchLib = async (book) => {
  try {
    const response = await axios.get('http://localhost:8080/2api/search/book', {
      params: {
        isbn: book.isbn,
        region: '29'  // 기본값으로 설정된 지역 코드
      }
    });

    console.log(response.data); // 응답 데이터 구조 확인

    if (response.data && response.data.response && Array.isArray(response.data.response.libs)) {
      libraryData.value = response.data.response.libs;
    } else {
      console.error('API 응답 구조가 예상과 다릅니다:', response.data);
      error.value = '소장 도서관 정보를 불러오는데 실패했습니다.';
    }
  } catch (error) {
    console.error('소장 도서관을 조회하는 중 오류가 발생했습니다.', error);
    error.value = '소장 도서관 조회 중 오류가 발생했습니다.';
  }
};


const handleAddBook = async () => {
  try {
    const response = await fetchWithAuth('/admin/books', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newBook)
    })
    if (response.ok) {
      await fetchBooks()
      Object.assign(newBook, { no: '', isbn: '', title: '', author: '', publish: '', date: '' })
    } else {
      error.value = '책을 추가하는 중 오류가 발생했습니다.'
    }
  } catch (err) {
    error.value = '네트워크 오류가 발생했습니다.2'
  }
}

const setEditBook = (book) => {
  editBook.value = { ...book }
}

const cancelEdit = () => {
  editBook.value = null
}

const handleEditBookSubmit = async () => {
  try {
    const response = await fetchWithAuth(`/admin/books/${editBook.value.no}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(editBook.value)
    })
    if (response.ok) {
      await fetchBooks()
      editBook.value = null
    } else {
      error.value = '책을 수정하는 중 오류가 발생했습니다.'
    }
  } catch (err) {
    error.value = '네트워크 오류가 발생했습니다.3'
  }
}

const handleDeleteBook = async (bookNo) => {
  try {
    const response = await fetchWithAuth(`/admin/books/${bookNo}`, {
      method: 'DELETE'
    })
    if (response.ok) {
      await fetchBooks()
    } else {
      error.value = '책을 삭제하는 중 오류가 발생했습니다.'
    }
  } catch (err) {
    error.value = '네트워크 오류가 발생했습니다.4'
  }
}

const prevPage = () => {
  if (currentPage.value > 0) {
    currentPage.value -= 1
    fetchBooks()
  }
}

const nextPage = () => {
  if (currentPage.value < totalPages.value - 1) {
    currentPage.value += 1
    fetchBooks()
  }
}

onMounted(fetchBooks)
</script>

<style scoped>
/* TailwindCSS styles used */
</style>
