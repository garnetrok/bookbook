<template>
  <div class="container mx-auto px-4 py-8 max-w-6xl">
    <h1 class="text-3xl font-bold mb-6">도서 관리</h1>
    <p v-if="error" class="text-red-500 mb-4">{{ error }}</p>
    <!-- 기존 폼 코드는 그대로 유지 -->
    <form @submit.prevent="handleAddBook" class="mb-8 bg-white shadow-md rounded px-8 pt-6 pb-8">
      <!-- 기존 폼 필드들... -->
    </form>
    <div class="overflow-x-auto">
      <ul class="flex flex-nowrap gap-4 pb-4">
        <li v-for="book in books" :key="book.no" class="flex-shrink-0 w-96 bg-white shadow-md rounded-lg p-4">
          <template v-if="editBook && editBook.no === book.no">
            <!-- 기존 수정 폼 코드... -->
          </template>
          <template v-else>
            <div class="mb-4">
              <h3 class="font-bold text-lg">{{ book.title }}</h3>
              <p class="text-sm text-gray-600">저자: {{ book.author }}</p>
              <p class="text-sm text-gray-600">출판사: {{ book.publish }}</p>
              <p class="text-sm text-gray-600">출판일: {{ book.date }}</p>
              <p class="text-sm text-gray-600">ISBN: {{ book.isbn }}</p>
            </div>
            <div class="flex justify-end space-x-2 mb-2">
              <button @click="searchLib(book)"
                class="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-1 px-2 rounded text-sm">
                소장 도서관 조회
              </button>
              <button @click="setEditBook(book)"
                class="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-1 px-2 rounded text-sm">
                수정
              </button>
              <button @click="handleDeleteBook(book.no)"
                class="bg-red-500 hover:bg-red-600 text-white font-bold py-1 px-2 rounded text-sm">
                삭제
              </button>
            </div>
            <!-- 소장 도서관 결과 출력 -->
            <div v-if="book.libraryData && book.libraryData.length > 0" class="mt-4">
              <h4 class="font-bold text-md">소장 도서관 목록:</h4>
              <ul class="max-h-40 overflow-y-auto">
                <li v-for="item in book.libraryData" :key="item.lib.libCode" class="text-sm text-gray-600">
                  {{ item.lib.libName }}
                </li>
              </ul>
            </div>
            <div v-else-if="book.libraryData && book.libraryData.length === 0" class="mt-4 text-sm text-gray-600">
              소장 도서관이 없습니다.
            </div>
            <div v-else-if="book.isSearching" class="mt-4 text-sm text-gray-600">
              도서관 정보를 조회 중입니다...
            </div>
          </template>
        </li>
      </ul>
    </div>
    <!-- 페이지네이션 컨트롤은 그대로 유지 -->
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { fetchWithAuth } from '../util/fetchWithAuth'
import axios from 'axios';

const books = ref([])
const loading = ref(true)
const error = ref('')
const newBook = reactive({
  no: '',
  isbn: '',
  title: '',
  author: '',
  publish: '',
  date: ''
})
const editBook = ref(null)
const currentPage = ref(0)
const totalPages = ref(0)

const fetchBooks = async () => {
  try {
    const response = await fetchWithAuth(`/admin/books?page=${currentPage.value}&size=5`)
    if (response.ok) {
      const data = await response.json()
      books.value = data.content.map(book => ({
        ...book,
        libraryData: null,
        isSearching: false
      }))
      totalPages.value = data.totalPages
    } else {
      error.value = '책 목록을 불러오는 중 오류가 발생했습니다.'
    }
  } catch (err) {
    error.value = '네트워크 오류가 발생했습니다.'
  }
}

const searchLib = async (book) => {
  if (book.libraryData) return; // 이미 검색된 경우 재검색 방지
  
  book.isSearching = true;
  try {
    const response = await axios.get('http://localhost:8080/2api/search/book', {
      params: {
        isbn: book.isbn,
        region: '29'  // 기본값으로 설정된 지역 코드
      }
    });

    if (response.data && response.data.response && Array.isArray(response.data.response.libs)) {
      book.libraryData = response.data.response.libs;
    } else {
      console.error('API 응답 구조가 예상과 다릅니다:', response.data);
      error.value = '소장 도서관 정보를 불러오는데 실패했습니다.';
      book.libraryData = [];
    }
  } catch (error) {
    console.error('소장 도서관을 조회하는 중 오류가 발생했습니다.', error);
    error.value = '소장 도서관 조회 중 오류가 발생했습니다.';
    book.libraryData = [];
  } finally {
    book.isSearching = false;
  }
};

// handleAddBook, setEditBook, cancelEdit, handleEditBookSubmit, handleDeleteBook 함수들은 그대로 유지

const prevPage = () => {
  if (currentPage.value > 0) {
    currentPage.value -= 1
    fetchBooks()
  }
}

const nextPage = () => {
  if (currentPage.value < totalPages.value - 1) {
    currentPage.value += 1
    fetchBooks()
  }
}

onMounted(fetchBooks)
</script>

<style scoped>
/* TailwindCSS styles used */
</style>
