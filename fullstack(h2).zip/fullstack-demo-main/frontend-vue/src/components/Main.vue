<template>
  <div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-4">메인 페이지</h1>
    <p class="text-lg">환영합니다! 이 페이지는 메인 페이지입니다.</p>
  </div>
</template>
