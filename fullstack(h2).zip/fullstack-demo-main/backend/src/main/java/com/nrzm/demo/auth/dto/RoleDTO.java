package com.nrzm.demo.auth.dto;

import lombok.Data;

@Data
public class RoleDTO {
    private Long id;
    private String name;
}
