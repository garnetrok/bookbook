module.exports = {
  content: [
    "./src/**/*.{html,js,vue}", // Vue 파일 및 HTML, JS 파일을 포함하도록 설정
    "./node_modules/flowbite/**/*.js" // Flowbite의 JS 파일 경로 추가
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Roboto', 'sans-serif'], // Roboto를 기본 sans 글꼴로 추가
      },
      colors: {
        gray: {
          // gray 색상을 수정하여 짙은 회색을 기본으로 설정
          50: '#F9FAFB',
          100: '#F3F4F6',
          200: '#E5E7EB',
          300: '#D1D5DB',
          400: '#9CA3AF',
          500: '#6B7280',  // 기본 gray 색상
          600: '#4B5563',  // 짙은 회색
          700: '#374151',
          800: '#1F2937',
          900: '#111827',
        },
      },
    }, // 필요에 따라 Tailwind 테마 확장
  },
  plugins: [
    require('flowbite/plugin') // Flowbite 플러그인 추가
  ],
}
