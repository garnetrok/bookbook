<template>
  <div class="book-card bg-white shadow rounded-lg p-4 cursor-pointer" @click="goToBookDetail">
    <img :src="book.coverImage || defaultImage" :alt="book.title" class="cover-image" />
    <h3 class="book-title">{{ book.title }}</h3>
    <p class="book-author">{{ book.author }}</p>
    <p class="book-publisher">{{ book.publisher }}</p>
  </div>
</template>

<script>
import { useRouter } from 'vue-router';
import defaultImage from '../data/images/defaultimage.jpg'; // 기본 이미지 경로 가져오기

export default {
  name: 'BookCard',
  props: {
    book: {
      type: Object,
      required: true
    }
  },
  setup(props) {
    const router = useRouter();

    const goToBookDetail = () => {
      router.push({ name: 'BookDetail', params: { id: props.book.id } });
    };

    return { goToBookDetail, defaultImage };
  }
}
</script>

<style scoped>
.book-card {
  width: 200px; /* Fixed width for all cards */
  height: 300px; /* Fixed height for all cards */
  transition: transform 0.2s;
  overflow: hidden; /* Prevent overflow of content */
  display: flex;
  flex-direction: column;
  justify-content: space-between; /* Distribute space evenly */
}

.cover-image {
  width: 100%;
  height: 150px; /* Fixed height for images */
  object-fit: cover; /* Ensure the image covers the area */
}

.book-title,
.book-author,
.book-publisher {
  margin: 0; /* Remove default margin */
  text-overflow: ellipsis; /* Truncate text with ellipsis */
  overflow: hidden; /* Hide overflow */
  white-space: nowrap; /* Prevent text from wrapping */
}

.book-title {
  font-size: 1rem; /* Adjust font size for title */
  font-weight: bold;
}

.book-author,
.book-publisher {
  font-size: 0.875rem; /* Adjust font size for author and publisher */
  color: #4a5568; /* Slightly darker gray */
}

/* Hover effect */
.book-card:hover {
  transform: scale(1.05);
}
</style>
