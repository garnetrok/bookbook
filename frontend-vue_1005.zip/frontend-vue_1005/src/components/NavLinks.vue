<template>
  <nav class="bg-blue-600 text-white p-4">
    <ul class="flex justify-center space-x-6">
      <li><router-link to="/" class="hover:text-yellow-300">메인</router-link></li>
      <li><router-link to="/booksearch" class="hover:text-yellow-300">도서검색</router-link></li>
      <li><router-link to="/recommendations" class="hover:text-yellow-300">추천도서</router-link></li>
      <li><router-link to="/librarysearch" class="hover:text-yellow-300">도서관검색</router-link></li>
      <li><router-link to="/admin" class="hover:text-yellow-300">관리자 로그인</router-link></li>
    </ul>
  </nav>
</template>

<script>
export default {
  name: 'NavLinks'
}
</script>