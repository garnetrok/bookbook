<template>
  <div class="book-detail flex">
    <img :src="book.coverImage" :alt="book.title" class="w-48 h-64 object-cover mr-6">
    <div>
      <h1 class="text-2xl font-semibold mb-2">{{ book.title }}</h1>
      <p class="text-lg">{{ book.author }}</p>
      <p class="text-md text-gray-600">{{ book.publisher }} ({{ book.publicationYear }})</p>
      <p class="mt-4">{{ book.description }}</p>
    </div>
  </div>
</template>

<script>
export default {
  name: 'BookDetail',
  props: {
    book: {
      type: Object,
      required: true
    }
  }
};
</script>