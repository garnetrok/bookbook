<!-- src/components/LibrarySearch.vue -->
<template>
  <div class="library-search">
    <input v-model="searchQuery" @input="search" type="text" placeholder="Search libraries..." class="w-full p-2 border rounded">
    <ul v-if="searchResults.length > 0" class="mt-4">
      <li v-for="library in searchResults" :key="library.id" class="bg-white shadow rounded-lg p-4 mb-2">
        {{ library.name }}
      </li>
    </ul>
  </div>
</template>

<script>
import { ref } from 'vue'

export default {
  name: 'LibrarySearch',
  setup() {
    const searchQuery = ref('')
    const searchResults = ref([])

    const search = () => {
      // 여기에 실제 도서관 검색 로직을 구현해야 합니다.
      // 현재는 더미 데이터를 사용합니다.
      searchResults.value = [
        { id: 1, name: 'Central Library' },
        { id: 2, name: 'Community Library' },
        { id: 3, name: 'University Library' }
      ].filter(library => library.name.toLowerCase().includes(searchQuery.value.toLowerCase()))
    }

    return {
      searchQuery,
      searchResults,
      search
    }
  }
}
</script>