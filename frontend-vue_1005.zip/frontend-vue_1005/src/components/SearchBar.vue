<!-- src/components/SearchBar.vue -->
<template>
  <div class="search-bar mb-4">
    <input 
      v-model="searchQuery" 
      @input="search"
      type="text" 
      placeholder="Search books..." 
      class="w-full p-2 border rounded"
    >
  </div>
</template>

<script>
import { ref } from 'vue'

export default {
  name: 'SearchBar',
  emits: ['search'],
  setup(props, { emit }) {
    const searchQuery = ref('')

    const search = () => {
      emit('search', searchQuery.value) // 검색어를 부모에 전달
    }

    return {
      searchQuery,
      search
    }
  }
}
</script>
