<!-- src/views/BookSearch.vue -->
<template>
  <div>
    <h1 class="text-2xl font-bold mb-4">도서 검색</h1>
    <SearchBar @search="handleSearch" />
    <BookList :books="paginatedBooks" />
    <div class="pagination">
      <button @click="prevPage" :disabled="currentPage === 1">이전</button>
      <span>페이지 {{ currentPage }} / {{ totalPages }}</span>
      <button @click="nextPage" :disabled="currentPage === totalPages">다음</button>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import SearchBar from '../components/SearchBar.vue'
import BookList from '../components/BookList.vue'
import booksData from '../data/books.js' // books.js에서 도서 데이터 가져오기

const currentPage = ref(1); // 현재 페이지
const searchQuery = ref(''); // 검색어
const books = ref(booksData.slice().reverse()); // 등록 순서가 늦은 것부터 가져오기 (배열을 반전)
const itemsPerPage = ref(0); // 페이지당 도서 수를 동적으로 설정

// 화면 크기에 따라 페이지당 도서 수를 조정하는 함수
const updateItemsPerPage = () => {
  const width = window.innerWidth;
  if (width >= 1024) {
    itemsPerPage.value = 5; // 대형 화면
  } else if (width >= 768) {
    itemsPerPage.value = 3; // 중형 화면
  } else {
    itemsPerPage.value = 1; // 소형 화면
  }
};

// 전체 페이지 수 계산
const totalPages = computed(() => Math.ceil(filteredBooks.value.length / itemsPerPage.value));

// 필터링된 도서 목록
const filteredBooks = computed(() => {
  if (!searchQuery.value) {
    return books.value; // 검색어가 없으면 모든 도서 반환
  }
  return books.value.filter(book => 
    book.title.includes(searchQuery.value) // 제목에 검색어가 포함된 도서만 반환
  );
});

// 페이지네이션된 도서 목록
const paginatedBooks = computed(() => {
  const start = (currentPage.value - 1) * itemsPerPage.value;
  const end = start + itemsPerPage.value;
  return filteredBooks.value.slice(start, end);
});

// 이전 페이지로 이동
const prevPage = () => {
  if (currentPage.value > 1) {
    currentPage.value--;
  }
};

// 다음 페이지로 이동
const nextPage = () => {
  if (currentPage.value < totalPages.value) {
    currentPage.value++;
  }
};

// 검색어 처리 함수
const handleSearch = (query) => {
  searchQuery.value = query; // 검색어 업데이트
  currentPage.value = 1; // 검색 시 첫 페이지로 리셋
};

// 화면 크기 변경 시 도서 수 업데이트
onMounted(() => {
  updateItemsPerPage(); // 초기 페이지당 도서 수 설정
  window.addEventListener('resize', updateItemsPerPage); // 화면 크기 변경 이벤트 리스너 추가
});

// 컴포넌트 언마운트 시 이벤트 리스너 제거
import { onBeforeUnmount } from 'vue';
onBeforeUnmount(() => {
  window.removeEventListener('resize', updateItemsPerPage);
});
</script>

<style scoped>
.pagination {
  display: flex;
  justify-content: center;
  margin-top: 20px;
}
.pagination button {
  margin: 0 10px;
  padding: 5px 10px;
  cursor: pointer;
}
.pagination button:disabled {
  background-color: #ccc;
  cursor: not-allowed;
}
</style>
