<template>
  <div class="book-recommendations">
    <h2 class="text-2xl font-semibold mb-4">추천 도서</h2>
    <div class="keywords">
      <div 
        v-for="keyword in keywords" 
        :key="keyword.code" 
        class="keyword-card" 
        @click="fetchBooksByKeyword(keyword.code)"
      >
        {{ keyword.label }}
      </div>
    </div>
    <BookList :books="recommendedBooks" />
  </div>
</template>

<script setup>
import BookList from '../components/BookList.vue'
import { ref, onMounted } from 'vue'
import books from '../data/books.js'

const recommendedBooks = ref([]);
const keywords = [
  { label: '어린이 문학', code: '아동' },
  { label: '과학', code: '500' },
  { label: '역사', code: '900' },
  { label: '예술', code: '700' },
  { label: '음악', code: '780' },
  { label: '자연', code: '500' },
  { label: '수학', code: '400' },
  { label: '문학', code: '800' },
  { label: '판타지', code: '아동' },
  { label: '탐험', code: '300' },
];

const fetchBooksByKeyword = (keyword) => {
  // 키워드에 따라 필터링된 도서 목록 설정
  recommendedBooks.value = books.filter(book => book.category === keyword);
};

onMounted(() => {
  // 처음에 랜덤하게 5권의 책을 추천
  recommendedBooks.value = books.sort(() => 0.5 - Math.random()).slice(0, 5);
});
</script>

<style scoped>
.keywords {
  display: grid; /* Use grid for a more flexible layout */
  grid-template-columns: repeat(5, 1fr); /* 5 cards per row */
  gap: 16px; /* Space between cards */
  margin-bottom: 20px;
}

.keyword-card {
  @apply rounded-lg bg-sky-200 cursor-pointer shadow-lg transition-transform duration-300 flex items-center justify-center text-black text-lg font-bold; /* Tailwind utility classes */
  height: 250px; /* Set a fixed height for the cards */
}

@media (max-width: 768px) {
  .keyword-card {
    height: 200px; /* Adjust height for smaller screens */
  }
}

@media (max-width: 480px) {
  .keyword-card {
    height: 150px; /* Adjust height for very small screens */
  }
}
</style>
