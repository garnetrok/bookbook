<template>
  <div>
    <h1 class="text-2xl font-bold mb-4">도서관 검색</h1>
    <LibrarySearch />
  </div>
</template>

<script setup>
import LibrarySearch from '../components/LibrarySearch.vue'
</script>
