import { createApp } from 'vue';
import App from './App.vue';
import router from './router'; // Vue Router 설정 가져오기
import './style.css'; // tailwind와 flowbite 스타일 파일 가져오기
createApp(App)
    .use(router) // Router를 애플리케이션에 추가
    .mount('#app'); // 앱을 #app 요소에 마운트
