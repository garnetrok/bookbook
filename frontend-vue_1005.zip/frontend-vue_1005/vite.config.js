import { defineConfig } from 'vite'; // defineConfig를 임포트합니다.
import vue from '@vitejs/plugin-vue'; // Vue 플러그인 임포트

export default defineConfig({
  base: '/',
  plugins: [vue()],
});
