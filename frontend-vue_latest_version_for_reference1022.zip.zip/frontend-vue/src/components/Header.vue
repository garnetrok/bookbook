<!-- pc navi bar는 헤더 푸터에서 수정해야 반영됨-->
<template>
    <header class="bg-blue-800 text-white p-6">
      <div class="container mx-auto flex justify-between items-center">
        <router-link to="/" class="text-3xl font-bold">나의 책꽂이</router-link>
        <nav>
          <router-link to="/book-search" class="mx-4 text-white hover:text-yellow-300">도서 검색</router-link>
          <router-link to="/book-search2" class="mx-4 text-white hover:text-yellow-300">도서 검색123</router-link>
          <router-link to="/book-recommendations" class="mx-4 text-white hover:text-yellow-300">추천 도서</router-link>
          <router-link to="/login" class="mx-4 text-white hover:text-yellow-300">로그인</router-link>
        </nav>
      </div>
    </header>
  </template>
  
  <script>
  export default {
    name: 'Header'
  }
  </script>
  
  <style scoped>
  /* 헤더 스타일 */
  </style>
  