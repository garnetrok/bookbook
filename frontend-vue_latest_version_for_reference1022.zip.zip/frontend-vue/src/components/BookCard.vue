<template>
  <div class="book-card bg-white shadow rounded-lg p-4 cursor-pointer" @click="goToDetail(book.no)">
    <img :src="book.image || defaultimage" :alt="book.title" class="cover-image" />
    <h3 class="book-title">{{ book.title }}</h3>
    <p class="book-author">{{ book.author }}</p>
    <p class="book-publisher">{{ book.publish }}</p>
    <!-- <p class="isbn">{{ book.isbn }}</p> -->
    <!-- Library Info Button -->
    <button class="library-button" @click="searchLib(book)">소장 도서관 조회</button>
  </div>


</template>

<script>
import { useRouter } from 'vue-router';
import defaultImage from '../data/images/defaultimage.jpg'; // 기본 이미지 경로 가져오기

export default {
  name: 'BookCard',
  props: {
    book: {
      type: Object,
      required: true
    }
  },
  setup(props) {
    const router = useRouter();

    const goToBookDetail = () => {
      router.push({ name: 'BookDetail', params: { id: props.book.id } });
    };

    const goToLibraryInfo = () => {
      // Add functionality to navigate to the library information page.
      alert(`조회할 도서관 정보: ${props.book.libraryInfo}`);
    };

    return { goToBookDetail, goToLibraryInfo, defaultImage };
  }
}
</script>

<style scoped>
.book-card {
  width: 200px; /* Fixed width for all cards */
  height: 400px; /* Increased height for button */
  transition: transform 0.2s;
  overflow: hidden; /* Prevent overflow of content */
  display: flex;
  flex-direction: column;
  justify-content: space-between; /* Distribute space evenly */
}

.cover-image {
  width: auto;
  height: 100%; /* Fixed height for images */
  max-height : 250px;
  object-fit: contain; /* Ensure the image covers the area */
}

.book-title,
.book-author,
.book-publisher {
  margin: 0; /* Remove default margin */
  text-overflow: ellipsis; /* Truncate text with ellipsis */
  overflow: hidden; /* Hide overflow */
  white-space: nowrap; /* Prevent text from wrapping */
}

.book-title {
  font-size: 1rem; /* Adjust font size for title */
  font-weight: bold;
}

.book-author,
.book-publisher {
  font-size: 0.875rem; /* Adjust font size for author and publisher */
  color: #4a5568; /* Slightly darker gray */
}

/* Library button style */
.library-button {
  margin-top: 10px;
  padding: 5px 10px;
  background-color: #4A5568; /* Dark gray background */
  color: white; /* White text */
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.library-button:hover {
  background-color: #2D3748; /* Darker gray on hover */
}

/* Hover effect */
.book-card:hover {
  transform: scale(1.05);
}
</style>
