<template>
  <div class="min-h-screen bg-gray-100">
    <!-- Header 컴포넌트 추가 -->
    <Header />

    <!-- Mobile Menu -->
    <template v-if="isMobile">
      <button @click="toggleMenu"
        class="fixed top-4 right-4 z-50 p-2 bg-blue-500 text-white rounded-full shadow-lg hover:bg-blue-600 transition-colors">
        <Bars3Icon class="h-6 w-6" />
      </button>
      <div v-if="isMenuOpen" class="fixed inset-0 bg-white z-40 p-4">
        <nav>
          <ul class="flex flex-col items-start pt-16">
            <NavLinks :currentRoute="currentRoute" :isAuth="isAuth" @updateAuth="updateAuth" />
          </ul>
        </nav>
      </div>
    </template>

    <!-- Main content -->
    <div class="container mx-auto px-4 py-8">
      <router-view @login="handleLogin"></router-view>
    </div>

    <!-- Footer 컴포넌트 추가 -->
    <Footer />
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, watch } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { Bars3Icon } from '@heroicons/vue/24/outline'
import NavLinks from './components/NavLinks.vue'
import Header from './components/Header.vue'
import Footer from './components/Footer.vue'

const router = useRouter()
const route = useRoute()

const isAuth = ref(false)
const isMenuOpen = ref(false)
const isMobile = ref(false)

const currentRoute = computed(() => route.path)

const checkAuth = () => {
  const token = sessionStorage.getItem("accessToken")
  isAuth.value = !!token
}

const handleResize = () => {
  isMobile.value = window.innerWidth <= 768
}

const toggleMenu = () => {
  isMenuOpen.value = !isMenuOpen.value
}

const handleLogin = () => {
  checkAuth()
}

const updateAuth = (newValue) => {
  isAuth.value = newValue
}

onMounted(() => {
  checkAuth()
  window.addEventListener("resize", handleResize)
  handleResize()
})

onUnmounted(() => {
  window.removeEventListener("resize", handleResize)
})
</script>
