<template>
  <div v-if="book" class="p-6">
    <div class="flex mb-8">
      <BookDetail :book="book" />
    </div>
    <div class="mt-8">
      <h2 class="text-xl font-semibold mb-4">Reviews</h2>
      <ReviewForm @submitReview="handleReviewSubmit" />
      
      <div v-if="reviews.length" class="mt-6">
        <div v-for="review in reviews" :key="review.id" class="review-card mb-4 p-4 bg-gray-50 rounded-lg border border-gray-200">
          <div class="flex items-center justify-between mb-2">
            <span class="text-sm text-gray-500">{{ formatDate(review.date) }}</span>
          </div>
          <p class="text-gray-700">{{ review.text }}</p>
          <div class="mt-2 text-sm text-gray-500">
            By <span class="font-semibold">Anonymous</span>
            <span class="ml-2 bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">Verified Purchase</span>
          </div>
        </div>
      </div>
     
    </div>
  </div>
  <div v-else class="p-6">
    <p>Loading...</p>
  </div>
</template>

<script>
import { ref, onMounted, watch } from 'vue';
import { useRoute } from 'vue-router';
import books from '../data/books';
import BookDetail from '../components/BookDetail.vue';
import ReviewForm from '../components/ReviewForm.vue';

export default {
  components: {
    BookDetail,
    ReviewForm
  },
  setup() {
    const route = useRoute();
    const book = ref(null);
    const reviews = ref([]);

    const loadBook = () => {
      const id = parseInt(route.params.id);
      book.value = books.find(b => b.id === id);
      console.log('Book loaded:', book.value);
    };

    const handleReviewSubmit = (review) => {
      reviews.value.push({
        id: Date.now(),
        date: new Date(),
        ...review
      });
    };

    const formatDate = (date) => {
      return new Date(date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
    };

    onMounted(loadBook);
    watch(() => route.params.id, loadBook);

    return { book, reviews, handleReviewSubmit, formatDate };
  }
};
</script>

<style scoped>
.review-card {
  transition: all 0.3s ease;
}

.review-card:hover {
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}
</style>