<<!-- src/views/Home.vue -->
<template>
  <div class="home flex flex-col items-center justify-center min-h-screen bg-gray-100">
    <h1 class="text-4xl font-bold text-gray-5 00 mb-4">책꽂이 'BookBook'에 오신 것을 환영합니다.</h1>
    <Main />
  </div>
</template>

<script>
import Main from '../components/Main.vue'

export default {
  name: 'Home',
  components: {
    Main
  }
}
</script>>