const defaultImage = 'data/images/defaultimage.jpg'; // 기본 이미지 경로

const books = [
    {
        id: 1,
        title: '어린이들의 모험: 수수께끼 탐험대',
        author: '한날 글, 그림, 파란정원',
        coverImage: 'data/images/image1.jpg',
        publisher: '파란정원',
        publicationYear: 2023,
        description: '어린이를 위한 재미있는 수수께끼 모음집',
        category: '아동', // 십진법 분류 추가
    },
    {
        id: 2,
        title: '고양이 해결사 깜냥: 가족을 찾아서',
        author: '홍민정 지음, 김재희 그림',
        coverImage: 'data/images/image2.jpg',
        publisher: '창비',
        publicationYear: 2023,
        description: '고양이 해결사 깜냥의 모험 시리즈 6번째 이야기',
        category: '아동',
    },
    {
        id: 3,
        title: '마법의 세계로 떠나는 여행',
        author: '이은주 저자',
        coverImage: 'data/images/image3.jpg',
        publisher: '새로운 출판사',
        publicationYear: 2023,
        description: '마법과 판타지로 가득한 이야기',
        category: '판타지',
    },
    {
        id: 4,
        title: '우주 탐험가: 별을 향한 도전',
        author: '김민수 글, 이지은 그림',
        coverImage: 'data/images/image4.jpg',
        publisher: '우주 출판사',
        publicationYear: 2023,
        description: '우주를 탐험하는 신나는 이야기',
        category: '과학',
    },
    {
        id: 5,
        title: '신비로운 동물들의 비밀',
        author: '박지현 지음',
        coverImage: 'data/images/image5.jpg',
        publisher: '자연 출판사',
        publicationYear: 2023,
        description: '신비로운 동물들의 이야기와 비밀을 탐구하는 책',
        category: '자연',
    },
    {
        id: 6,
        title: '꿈꾸는 공주: 마법의 성',
        author: '이수진 저자',
        coverImage: 'data/images/image6.jpg',
        publisher: '행복 출판사',
        publicationYear: 2023,
        description: '환상적인 꿈과 모험의 이야기',
        category: '아동',
    },
    {
        id: 7,
        title: '역사 속 숨겨진 보물 찾기',
        author: '장유진 지음',
        coverImage: 'data/images/image7.jpg',
        publisher: '탐험 출판사',
        publicationYear: 2023,
        description: '역사 속 보물을 찾아가는 모험 이야기',
        category: '역사',
    },
    {
        id: 8,
        title: '기발한 발명품의 비밀',
        author: '오진우 저자',
        coverImage: 'data/images/image8.jpg',
        publisher: '아이디어 출판사',
        publicationYear: 2023,
        description: '창의적인 발명품의 숨겨진 이야기를 알아보세요',
        category: '과학',
    },
    {
        id: 9,
        title: '바다 탐험대: 신비한 해양 세계',
        author: '정민우 글, 한영미 그림',
        coverImage: 'data/images/image9.jpg',
        publisher: '바다 출판사',
        publicationYear: 2023,
        description: '바다의 신비로운 세계를 탐험하는 이야기',
        category: '자연',
    },
    {
        id: 10,
        title: '숲 속의 친구들: 자연 탐방',
        author: '김소영 지음',
        coverImage: 'data/images/image10.jpg',
        publisher: '자연 출판사',
        publicationYear: 2023,
        description: '숲 속의 다양한 친구들을 만나는 이야기',
        category: '자연',
    },
    {
        id: 11,
        title: '사계절의 이야기: 변화하는 자연',
        author: '정하늘 저자',
        coverImage: 'data/images/image11.jpg',
        publisher: '시간 출판사',
        publicationYear: 2023,
        description: '사계절의 변화와 자연의 아름다움을 탐구하는 책',
        category: '자연',
    },
    {
        id: 12,
        title: '과학의 신비: 신기한 실험들',
        author: '최민지 지음',
        coverImage: 'data/images/image12.jpg',
        publisher: '과학 출판사',
        publicationYear: 2023,
        description: '흥미로운 과학 실험을 통해 배우는 책',
        category: '과학',
    },
    {
        id: 13,
        title: '음악의 마법: 소리의 세계',
        author: '한상우 저자',
        coverImage: 'data/images/image13.jpg',
        publisher: '예술 출판사',
        publicationYear: 2023,
        description: '음악의 아름다움과 힘을 탐구하는 이야기',
        category: '음악',
    },
    {
        id: 14,
        title: '타임머신을 타고: 시간 여행',
        author: '강태훈 글, 이영희 그림',
        coverImage: 'data/images/image14.jpg',
        publisher: '미래 출판사',
        publicationYear: 2023,
        description: '시간 여행을 통해 역사 속으로 떠나는 이야기',
        category: '역사',
    },
    {
        id: 15,
        title: '정글 탐험: 생명의 신비',
        author: '백종호 지음',
        coverImage: 'data/images/image15.jpg',
        publisher: '자연 출판사',
        publicationYear: 2023,
        description: '정글의 다양한 생명체를 탐험하는 모험 이야기',
        category: '자연',
    },
];

// 기본 이미지가 필요한 경우 체크하는 함수
function getCoverImage(imagePath) {
    // 이미지 파일이 존재하는지 확인하는 방법을 실제 코드로 구현할 수 없습니다.
    // 따라서, 여기서는 경로가 "data/images/imageX.jpg" 형식이 아닌 경우 기본 이미지로 대체합니다.
    if (!imagePath || !imagePath.startsWith('data/images/image')) {
        return defaultImage;
    }
    return imagePath;
}

// 각 책의 이미지 경로를 체크
books.forEach(book => {
    book.coverImage = getCoverImage(book.coverImage);
});

export default books;
